CREATE USER 'SeniorProjects' IDENTIFIED BY 'Password';
GRANT ALL ON MedLink TO SeniorProjects;

CREATE TABLE userid (
	UserID int auto_increment NOT NULL PRIMARY KEY,
	UserName varchar(128) COLLATE utf8mb4_general_ci DEFAULT NULL,
	Password varchar(128) COLLATE utf8mb4_general_ci DEFAULT NULL,
	Email varchar(128) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE secretary (
	SecretaryID int NOT NULL PRIMARY KEY,
	UserID int DEFAULT NULL,
	FirstName varchar(128) COLLATE utf8mb4_general_ci DEFAULT NULL,
	LastName varchar(128) COLLATE utf8mb4_general_ci DEFAULT NULL,
	FOREIGN KEY (UserID) REFERENCES UserId(UserId)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE patient (
	PatientID int NOT NULL PRIMARY KEY,
	UserID int DEFAULT NULL,
	FamilyID int DEFAULT NULL,
	FirstName varchar(128) COLLATE utf8mb4_general_ci DEFAULT NULL,
	LastName varchar(128) COLLATE utf8mb4_general_ci DEFAULT NULL,
	DateOfBirth date DEFAULT NULL,
	EmergencyName varchar(128) COLLATE utf8mb4_general_ci DEFAULT NULL,
	EmergencyPhoneNumber varchar(15) COLLATE utf8mb4_general_ci DEFAULT NULL,
	Allergies varchar(128) COLLATE utf8mb4_general_ci DEFAULT NULL,
	Conditions varchar(128) COLLATE utf8mb4_general_ci DEFAULT NULL,
	ExistingIllnesses varchar(128) COLLATE utf8mb4_general_ci DEFAULT NULL,
	BloodPressure int DEFAULT NULL,
	SugarLevels int DEFAULT NULL,
	FOREIGN KEY (UserID) REFERENCES UserId(UserId)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE doctor (
	DoctorID int NOT NULL,
	UserID int DEFAULT NULL,
	FirstName varchar(128) COLLATE utf8mb4_general_ci DEFAULT NULL,
	LastName varchar(128) COLLATE utf8mb4_general_ci DEFAULT NULL,
	FOREIGN KEY (UserID) REFERENCES UserId(UserId)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;