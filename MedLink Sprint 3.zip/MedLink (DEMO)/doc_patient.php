<?php 

    session_start();

    // Check if the user is logged in
    if (isset($_SESSION['username'])) {
      $usernameSession = $_SESSION['username'];
    } else {
      // Redirect to the login page if the user is not logged in
      header("Location: login.html");
    }

    // Connection to database
    $server = 'localhost';
    $username = 'SeniorProjects';
    $password = 'Password';
    $db = 'MedLink';

    $conn = new mysqli($server, $username, $password, $db);
 ?>


<!DOCTYPE html>
<html>
<head>
    <title>Med Link Doctor Homepage</title>
    <link rel="stylesheet" href="layout.css">
    <link rel="stylesheet" href="doc_patient.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
</head>
<body>
    <!-- Top Nav Bar -->
    <header>
        <a href="doc_homepage.php"><img class="logo" src="img/MedLink_Logo.png" alt="logo"></a>
        <nav>
            <ul class="nav_buttons">
                <li><a href="doc_calendar.php"><span class="material-icons">calendar_month</span>Calender</a></li>
                <li><a href="#"><span class="material-icons">medication</span>Medication</a></li>
                <li><a href="doc_patient.php"><span class="material-icons">man</span>Patients</a></li>
                <li><a href="#"><span class="material-icons">mail</span>Message</a></li>
            </ul>
        </nav>
        <a href="#"><span class="material-icons">menu</span></a>
    </header>

   <!-- Body of Page -->
    <main>
        <div class="header">Patient List</div>
        <div class="content">
            <!-- Left Side -->
            <div class="container1">
                <!-- initiation of php loop to generate patient cards -->
                <?php 
                
                // SQL query to retrieve patient information
                    $sql = "SELECT FirstName, LastName, FamilyID FROM patient";
                    $result = $conn->query($sql);

                    if ($result === false) {
                        // Query execution failed
                        echo "Error: " . $conn->error;
                    } else {
                        while ($row = $result->fetch_assoc()) {
                            // Display patient information for each row
                            ?>
                            <!-- Patient Card -->
                            <div class="card">
                                <div class="info">
                                    <div class="name">
                                        <?php echo $row["FirstName"] . " " . $row["LastName"]; ?>
                                    </div>
                                    <div class="family">
                                        <?php echo $row["FamilyID"]; ?>
                                    </div>
                                </div>
                                <div class="button">
                                    <input type="submit" value="Click For More Info" name="info">
                                </div>
                            </div>
                            <?php
                        }
                    }

                        // Close the database connection
                        $conn->close();
                        ?>
            </div>
            <!-- Right Side -->
            <div class="container2">
                <!-- Pateint More Info Card -->
                <div class="patient">
                    <!-- Top of info Card -->
                    <div class="top">
                        <!-- Patient Info -->
                        <div class="info">
                            <div>
                                {FirstName LastName}
                            </div>
                            <div>
                                Age: {Age}
                            </div>
                            <div>
                                Gender: {Gender}
                            </div>
                            <div>
                                Current Medications:
                            </div>
                            <ul>
                                <?php for ($x = 0; $x <= 20; $x++) { ?>
                                    <li>
                                        {Drug}
                                    </li>
                                <?php } ?>
                            </ul>
                        </div>
                        <!-- Family Info -->
                        <!-- implement php to check if patient has family attached -->
                        <div class="family">
                            Other Family Members
                        </div>
                    </div>
                    <!-- Appointments -->
                    <!-- implement php to check if patient has upcoming visits -->
                    <div class="visit">
                        Next Visit:
                    </div>
                    
                </div> 
            </div>
        </div>
    </main>

    <!-- Bottom Nav Bar -->
    <footer>
        <ul class="nav_buttons">
            <li><a href="#">Rules of Conduct</a></li>
            <li><a href="#">Privacy Policy</a></li>
            <li><a href="#">Need Help?</a></li>
        </ul>
    </footer>
</body>
</html> 