<?php 
    session_start();

    // Check if the user is logged in
    if (isset($_SESSION['username'])) {
    $usernameSession = $_SESSION['username'];
    } else {
    // Redirect to the login page if the user is not logged in
    header("Location: login.html");
    }
?>

<!DOCTYPE html>
<html>
<head>
    <title>Med Link Doctor Homepage</title>
    <link rel="stylesheet" href="layout.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
</head>
<body>
    <!-- Top Nav Bar -->
    <header>
        <a href="doc_homepage.php"><img class="logo" src="img/MedLink_Logo.png" alt="logo"></a>
        <nav>
            <ul class="nav_buttons">
                <li><a href="doc_calendar.php"><span class="material-icons">calendar_month</span>Calender</a></li>
                <li><a href="#"><span class="material-icons">medication</span>Medication</a></li>
                <li><a href="doc_patient.php"><span class="material-icons">man</span>Patients</a></li>
                <li><a href="#"><span class="material-icons">mail</span>Message</a></li>
            </ul>
        </nav>
        <a href="#"><span class="material-icons">menu</span></a>
    </header>

   <!-- Body of Page -->
    <main>
         <!--adding my code here-->
         <link rel="stylesheet" href="calendar.css">
        <div class="calendarmain">
           
            <div class="month">
                <ul>
                    <li class="previousmonth">&#10094;</li>
                    <li class="nextmonth">&#10095;</li>
                    <li class="currentmonth">September 2023<br></li>
                </ul>
            </div>
            
            <ul class ="weekday">
                <li>Monday</li>
                <li>Tuesday</li>
                <li>Wednesday</li>
                <li>Thursday</li>
                <li>Friday</li>
                <li>Saturday</li>
                <li>Sunday</li>
            </ul>

            <ul class="numbers">
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li>1</li>
                <li>2</li>
                <li>3</li>
                <li>4</li>
                <li>5</li>
                <li>6</li>
                <li>7</li>
                <li>8</li>
                <li>9</li>
                <li>10</li>
                <li>11</li>
                <li>12</li>
                <li>13</li>
                <li>14</li>
                <li>15</li>
                <li>16</li>
                <li>17</li>
                <li>18</li>
                <li>19</li>
                <li>20</li>
                <li>21</li>
                <li>22</li>
                <li>23</li>
                <li>24</li>
                <li>25</li>
                <li>26</li>
                <li class="currentday">27</li>
                <li>28</li>
                <li>29</li>
                <li>30</li>
                <li>31</li>
            </ul>
        </div>
    </div>

    <ul class="appointments">Upcoming Appointments</ul>
            <div class="patientappt1"><p>11:30 AM David Talero</p><p style="text-align: right;">Click for more info</p></div>
            <div class="patientappt2"><p>12:00 PM Kassandra Smith</p><p style="text-align: right;">Click for more info</p></div>
            <div class="patientappt3"> <p>12:30 PM Merideth Bass</p><p style ="text-align: right;">Click for more info</p></div>
            <div class="patientappt4"><p>01:00 PM Kevin Warner</p><p style="text-align: right;">Click for more info</p></div>
            <div class="patientappt5"><p>01:30 PM Hilda Hassad</p><p style="text-align: right;">Click for more info</p></div>
            <div class="patientappt6"><p>02:00 PM Joesph Grasso</p><p style="text-align: right;"> Click for more info</p></div>
      
    </main>

    <!-- Bottom Nav Bar -->
    <footer>
        <ul class="nav_buttons">
            <li><a href="#">Rules of Conduct</a></li>
            <li><a href="#">Privacy Policy</a></li>
            <li><a href="#">Need Help?</a></li>
        </ul>
    </footer>
</body>
</html> 