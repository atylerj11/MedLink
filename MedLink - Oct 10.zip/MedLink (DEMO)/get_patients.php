<?php
    // Connection to database
        $server = 'localhost';
        $username = 'SeniorProjects';
        $password = 'Password';
        $db = 'MedLink';

        $conn = new mysqli($server, $username, $password, $db);

        if ($conn->connect_error) {
            die("Fatal Error: Database Connection");
        }

        // Query to fetch patients from the PATIENT table
        $sql = "SELECT FirstName, LastName FROM PATIENT";
        $result = $conn->query($sql);

        // Initialize an empty array to store patient data
        $patients = array();

        // Fetch and store patient data
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $patients[] = $row;
            }
        }

        // Close the database connection
        $conn->close();

        // Return the patient data as JSON
        echo json_encode($patients);
    ?>