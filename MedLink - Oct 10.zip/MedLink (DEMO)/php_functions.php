<?php 
    // Connection to database
    $server = 'localhost';
    $username = 'SeniorProjects';
    $password = 'Password';
    $db = 'MedLink';

    $conn = new mysqli($server, $username, $password, $db);

    if ($conn->connect_error) {
        die("Fatal Error: Database Connection");
    }
    
    // gets information from patient table
    if (isset($_GET['moreInfoFilter'])) {
        $filter = $_GET['moreInfoFilter'];

        // select statement
        $sql = "SELECT * FROM patient WHERE PatientID = $filter";
        $result = $conn->query($sql);

        if ($result === false) {
            // Query execution failed
            echo "Error: " . $conn->error;
        }

        // Fetch data into an array
        $data = array();
        while ($row = $result->fetch_assoc()) {
            $data = $row;
        }

        // Return data as JSON for the javascript function
        header('Content-Type: application/json');
        echo json_encode($data);
    }

    // gets information from prescription table
    if (isset($_GET['drugFilter'])) {
        $filter = $_GET['drugFilter'];

        // select statement
        $sql = "SELECT * FROM prescription WHERE PatientID = $filter";
        $result = $conn->query($sql);

        if ($result === false) {
            // Query execution failed
            echo "Error: " . $conn->error;
        }

        // Fetch data into an array
        $data = array();
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }

        // Return data as JSON for the javascript function
        header('Content-Type: application/json');
        echo json_encode($data);
    }

    // gets information from appointment table
    if (isset($_GET['visitFilter'])) {
        $filter = $_GET['visitFilter'];

        // select statement, checking for patientid, on or past current date and ordered by date, then only get 1
        $sql = "SELECT * FROM appointment 
        WHERE PatientID = $filter
        AND `Date` >= CURRENT_DATE()
        ORDER BY `Date`  ASC
        LIMIT 1";
        $result = $conn->query($sql);

        if ($result === false) {
            // Query execution failed
            echo "Error: " . $conn->error;
        }

        // Fetch data into an array
        $data = array();
        while ($row = $result->fetch_assoc()) {
            $data = $row;
        }

        // Return data as JSON for the javascript function
        header('Content-Type: application/json');
        echo json_encode($data);
    }

    if (isset($_GET['emailFilter'])) {
        $filter = $_GET['emailFilter'];

        // select statement, checking for patientid, on or past current date and ordered by date, then only get 1
        $sql = 
            "SELECT patient.PatientID, patient.FirstName, patient.LastName, userid.email
            FROM patient 
            JOIN userid 
            ON patient.UserID = userid.UserID
            WHERE patient.patientID = $filter";
        $result = $conn->query($sql);

        if ($result === false) {
            // Query execution failed
            echo "Error: " . $conn->error;
        }

        // Fetch data into an array
        $data = array();
        while ($row = $result->fetch_assoc()) {
            $data = $row;
        }

        // Return data as JSON for the javascript function
        header('Content-Type: application/json');
        echo json_encode($data);
    }

    // Close the database connection
    $conn->close();
 ?>