<?php 

    session_start();

    // Check if the user is logged in
    if (isset($_SESSION['username'])) {
      $usernameSession = $_SESSION['username'];
    } else {
      // Redirect to the login page if the user is not logged in
      header("Location: login.html");
    }

    // Connection to database
    $server = 'localhost';
    $username = 'SeniorProjects';
    $password = 'Password';
    $db = 'MedLink';

    $conn = new mysqli($server, $username, $password, $db);

    if ($conn->connect_error) {
        die("Fatal Error: Database Connection");
    }

    //query changed to using username
    $queryResult = mysqli_query($conn, "SELECT * FROM userid WHERE username = '$usernameSession'");
    //store querry into an array
    $row = mysqli_fetch_assoc($queryResult);
 ?>

<!DOCTYPE html>
<html>
<head>
    <title>Med Link Doctor Homepage</title>
    <link rel="stylesheet" href="layout.css">
    <link rel="stylesheet" href="doc_homepage.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
</head>
<body>
    <!-- Top Nav Bar -->
    <header>
        <a href="doc_homepage.php"><img class="logo" src="img/MedLink_Logo.png" alt="logo"></a>
        <nav>
            <ul class="nav_buttons">
                <li><a href="doc_calendar.php"><span class="material-icons">calendar_month</span>Calender</a></li>
                <li><a href="doc_create_prescription.php"><span class="material-icons">medication</span>Medication</a></li>
                <li><a href="doc_patient.php"><span class="material-icons">man</span>Patients</a></li>
                <li><a href="#"><span class="material-icons">mail</span>Message</a></li>
            </ul>
        </nav>
        <a href="logout.php"><span class="material-icons">menu</span></a>
    </header>

   <!-- Body of Page -->
    <main>
        <!-- Left Side -->
        <div class="container1">
            <div class="con_welcome">
                <div class="welcome">Welcome back</div>
                <div class="name">Dr. 
                    <?php 
                        //get value from array under LastNameField
                        echo "{$row['LastName']}";
                    ?>
                    </div>
            </div>
            <div class="upcoming">Today's Upcoming Appointments</div>
            <div class="con_appointment">
                <!-- initiation of php loop to generate appointment cards -->
                <?php for ($x = 0; $x <= 10; $x++) { ?>
                    <!-- Appointment Card -->
                    <div class="card">
                        <div class="info">
                            <div class ="name">
                                 {FirstName} {LastName}
                            </div>
                            <div class ="time">
                                {Time}
                            </div>
                        </div>
                    </div>
                <?php } ?>
                <!-- end php loop -->
            </div>
        </div>
        <!-- Right Side -->
        <div class="container2">
            <nav>
                <li><a href="#" class="blue">Create Appointment<br>Report</a></li>
                <li><a href="#" class="white">Manage Prescription<br>Info</a></li>
                <li><a href="doc_patient.php" class="blue">Manage Patient Info</a></li>    
            </nav>
        </div>
        
    </main>

    <!-- Bottom Nav Bar -->
    <footer>
        <ul class="nav_buttons">
            <li><a href="#">Rules of Conduct</a></li>
            <li><a href="#">Privacy Policy</a></li>
            <li><a href="#">Need Help?</a></li>
        </ul>
    </footer>
</body>
</html> 