<!DOCTYPE html>
<html>
<head>
    <title>Med Link Patient Homepage</title>
    <link rel="stylesheet" href="layout.css">
    <link rel="stylesheet" href="patient_medication.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
</head>
<body>
    <!-- Top Nav Bar -->
    <header>
        <a href="patient_homepage.php"><img class="logo" src="img/MedLink_Logo.png" alt="logo"></a>
        <nav>
            <ul class="nav_buttons">
                <li><a href="#"><span class="material-icons">calendar_month</span>Calender</a></li>
                <li><a href="patient_medication.php"><span class="material-icons">medication</span>Medication</a></li>
                <li><a href="#"><span class="material-icons">science</span>Results</a></li>
                <li><a href="#"><span class="material-icons">mail</span>Message</a></li>
            </ul>
        </nav>
        <a href="#"><span class="material-icons">menu</span></a>
    </header>
   
    <!-- Body of Page -->
    <main>
        <!-- Left Side -->
        <div class="container1">
            <div class="view-msg">View Medication</div>
            <!-- Dropdown Menu -->
            <div class="dropdown">
                <form>
                    <label for="patient"><b>Patient:</b></label>
                    <select name="patient" id="patient">
                        <option value="patient-1">{FirstName LastName} (Father)</option>
                        <option value="patient-2">{FirstName LastName} (Daughter)</option>
                        <option value="patient-3">{FirstName LastName} (Son)</option>
                        <option value="patient-4">{FirstName LastName} (Granma)</option>
                    </select>
                    <input type="submit" value="View">
                </form>
            </div>
        </div>
        <!-- Right Side -->
        <div class="container2">
            <!-- initiation of php loop to generate appointment cards -->
            <?php for ($x = 0; $x <= 10; $x++) { ?> 
                <!-- Drug Card -->
                <div class="card">
                    <div class="drug"><b>{Drug Name} </b><?php echo "$x"; ?></div>
                    <div class="date">
                        <div class="given-date">
                            <b>Prescribed: </b>{Prescibe Date}
                        </div>
                        <div class="done-date">
                            <b>Last Until: </b>{Done Date}
                        </div>
                    </div>
                    <div class="reason">
                        <b>Reason: </b>
                        {Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
                        Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.} 
                    </div>
                    <div class="instructions">
                        <b>How to take: </b>
                        {Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
                        Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.} 
                    </div>
                    <form>
                        <input type="submit" value="Request Refill">
                    </form>
                    </div>
                <?php } ?>
                <!-- end php loop -->
        </div>
        
    </main>

    <!-- Bottom Nav Bar -->
    <footer>
        <ul class="nav_buttons">
            <li><a href="#">Rules of Conduct</a></li>
            <li><a href="#">Privacy Policy</a></li>
            <li><a href="#">Need Help?</a></li>
        </ul>
    </footer>
</body>
</html> 