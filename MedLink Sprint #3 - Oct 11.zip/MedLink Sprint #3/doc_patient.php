<?php 
    // Session Code
    session_start();

    // Check if the user is logged in
    if (isset($_SESSION['username'])) {
      $usernameSession = $_SESSION['username'];
    } else {
      // Redirect to the login page if the user is not logged in
      header("Location: login.html");
    }

    // Connection to database
    $server = 'localhost';
    $username = 'SeniorProjects';
    $password = 'Password';
    $db = 'MedLink';

    $conn = new mysqli($server, $username, $password, $db);

    if ($conn->connect_error) {
        die("Fatal Error: Database Connection");
    }
 ?>
<!DOCTYPE html>
<html>
<head>
    <title>Med Link Doctor Homepage</title>
    <link rel="stylesheet" href="DocLayout.css">
    <link rel="stylesheet" href="doc_patient.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

<script>
//search for patient info to fill in more info card
function patient_info(patient) {
    // Checks if the info card is hidden or visible, if it is, sets it to be visible
    var infoCard = document.getElementById("infoCard");
    if (window.getComputedStyle(document.getElementById("infoCard")).display === "none") {
        infoCard.style.display = "flex";
    }

    //sends the patientid to php script to get patient info
    fetch('php_functions.php?moreInfoFilter=' + patient)
        .then(response => response.json())
        .then(data => {
            // Store the data in an associative array
            let patientData = data;
            // console.log(patientData); //outputs to console for debug
            //each line fills in relavent HTML area with information stored in the array from the PHP script
            document.getElementById("name").textContent = patientData.FirstName + " " + patientData.LastName;
            document.getElementById("dob").textContent = patientData.DateOfBirth;
            document.getElementById("gender").textContent = patientData.Gender;
            document.getElementById("emergencyName").textContent = patientData.EmergencyName;
            document.getElementById("emergency#").textContent = patientData.EmergencyPhoneNumber;
            document.getElementById("allergies").textContent = patientData.Allergies;
            document.getElementById("sugar").textContent = patientData.SugarLevels;
            document.getElementById("bloodPressure").textContent = patientData.BloodPressure;
            document.getElementById("condition").textContent = patientData.Conditions;
            document.getElementById("illness").textContent = patientData.ExistingIllnesses;
        })

    //sends the patientid to php script to get drug info
    fetch('php_functions.php?drugFilter=' + patient)
        .then(response => response.json())
        .then(data => {
            // Store the data in an associative array
            let drugData = data;
            // console.log(drugData); //outputs to console for debug
            //targets the drug list section
            var drugList = document.getElementById("drugs");
            //empties out previous list
            drugList.innerHTML = "";

            //If no prescriptions are returned
            if (drugData.length == 0) {
                //create new list element
                var listItem = document.createElement("li");
                //creates a list item filled with 
                listItem.textContent = "None";
                //adds the list item to the end of the list
                drugList.appendChild(listItem);
            }
            //if drugs are returned
            else {
                for (var i = 0; i < drugData.length; i++) {
                //create new list element
                var listItem = document.createElement("li");
                //creates a list item filled with 
                listItem.textContent = drugData[i].Name;
                //adds the list item to the end of the list
                drugList.appendChild(listItem);
                }
            }
        })

    //sends the patientid to php script to get appoinment info
    fetch('php_functions.php?visitFilter=' + patient)
        .then(response => response.json())
        .then(data => {
            // Store the data in an associative array
            let visitData = data;
            // console.log(visitData); //outputs to console for debug

            //If no appointments are returned
            if (visitData.length == 0) {
                document.getElementById("date").textContent = "None";
            }
            // if there is an appointment returned
            else {
                document.getElementById("date").textContent = visitData.Type + " on " + visitData.Date;
            }
        })
}

//search through patient cards
function searchPatients() {
    var search = document.getElementById("search").value.toLowerCase();
    var cards = document.getElementsByClassName("card");

    for (var i = 0; i < cards.length; i++) {
            var name = cards[i].getElementsByClassName("name")[0].textContent.toLowerCase();
            if (name.includes(search)) {
                cards[i].style.display = "flex";
            } else {
                cards[i].style.display = "none";
            }
    }
}
</script>

</head>
<body>
    <!-- Top Nav Bar -->
    <header>
        <a href="doc_homepage.php"><img class="logo" src="img/MedLink_Logo.png" alt="logo"></a>
        <nav>
            <ul class="nav_buttons">
                <li><a href="#"><span class="material-icons">calendar_month</span>Calendar</a></li>
                <li><a href="doc_create_prescription.php"><span class="material-icons">medication</span>Medication</a></li>
                <li><a href="doc_patient.php"><span class="material-icons">man</span>Patients</a></li>
                <li><a href="doc_message.php"><span class="material-icons">mail</span>Message</a></li>
            </ul>
        </nav>
        <a href="#"><span class="material-icons">menu</span></a>
    </header>

   <!-- Body of Page -->
    <main>
        <div class="header">Patient List</div>
        <div class="content">
            <!-- Left Side -->
            <div class="container1">
                <div class="inputArea">
                    <input type="text" id="search" name="search" placeholder="" onkeyup="searchPatients()">
                    <label class="label">Search</label>
                    <span class="bottomBorder"></span>
                    <span class="bar"></span>
                </div>
                <div class="container2">
                     <!-- initiation of php loop to generate patient cards -->
                    <?php 
                        // SQL query to retrieve patient information
                        $sql = "SELECT PatientID, FirstName, LastName, FamilyID FROM patient";
                        $result = $conn->query($sql);

                        if ($result === false) {
                            // Query execution failed
                            echo "Error: " . $conn->error;
                        } else {
                            while ($row = $result->fetch_assoc()) {
                                // Display patient information for each row
                                ?>
                                <!-- Patient Card -->
                                <div class="card ">
                                    <div class="info">
                                        <div class="name">
                                            <?php echo $row["FirstName"] . " " . $row["LastName"]; ?>
                                        </div>
                                        <div class="family">
                                            <?php echo $row["FamilyID"]; ?>
                                        </div>
                                    </div>
                                    <div class="btn">
                                        <!-- makes a button and sends php variable of the cards patient to the JS function -->
                                        <form method="post" action="doc_update_patient.php">
                                            <button type="submit" name="update" value="<?php echo $row['PatientID'];?>">Update Patient</button>
                                        </form>
                                        <button onclick="patient_info('<?php echo $row['PatientID']; ?>')">Click for More Info</button>
                                    </div>
                                </div>
                                <?php
                            }
                            $conn->close();
                        }
                    ?>
                </div>
            </div>
            <!-- Right Side -->
            <div class="container3">
                <div id="infoCard" class="patient">
                    <!-- Top of info Card -->
                    <div class="top">
                        <!-- Patient Info, filled in from JavaScript function-->
                        <div class="left_info">
                            <div>
                                <b><span id="name"></span></b>
                            </div>
                            <div>
                                <b>Date of Birth: </b><span id="dob"></span>
                            </div>
                            <div>
                                <b>Gender: </b><span id="gender"></span>
                            </div>
                            <div>
                                <b>Emergency Contact: </b><span id="emergencyName"></span>
                            </div>
                            <div>
                                <b>Emergency Contact #: </b><span id="emergency#"></span>
                            </div>
                            <div>
                                <b>Current Medications:</b>
                            </div>
                            <ul id="drugs">
                                <li>{Drug}</li>
                            </ul>
                        </div>
                        <!-- Right Info -->
                        <div class="right_info">
                            <div>
                                <b>Allergies: </b><span id="allergies"></span>
                            </div>
                            <div>
                                <b>Sugar Levels: </b><span id="sugar"></span>
                            </div>
                            <div>
                                <b>Blood Pressure: </b><span id="bloodPressure"></span>
                            </div>
                            <div>
                                <b>Conditions: </b><span id="condition"></span>
                            </div>
                            <div>
                                <b>Exisiting Illnesses: </b><span id="illness"></span>
                            </div>
                        </div>
                    </div>
                    <!-- Appointments -->
                    <div>
                        <b>Next Visit:</b>
                        <div id="date"></div>
                    </div>
                    
                </div>        
            </div>
        </div>
    </main>

    <!-- Bottom Nav Bar -->
    <footer>
        <ul class="nav_buttons">
            <li><a href="#">Rules of Conduct</a></li>
            <li><a href="#">Privacy Policy</a></li>
            <li><a href="#">Need Help?</a></li>
        </ul>
    </footer>
</body>
</html> 