<?php
    // Connection to database
        $server = 'localhost';
        $username = 'SeniorProjects';
        $password = 'Password';
        $db = 'MedLink';

        $conn = new mysqli($server, $username, $password, $db);

        if ($conn->connect_error) {
            die("Fatal Error: Database Connection");
        }

        if (isset($_POST['appointmentID'])) {
            $appointmentID = $_POST['appointmentID'];
        }

        // SQL query to insert the prescription into the "prescriptions" table
        $sql = "DELETE FROM appointment WHERE appointmentID = ?";

        // Prepare the SQL statement
        $stmt = $conn->prepare($sql);

        if ($stmt) {
            // Bind the parameters and execute the query
            $stmt->bind_param("s", $appointmentID);
            if ($stmt->execute()) {
                header("Location: success.php?success=5");
            } else {
                header("Location: error.php?error=9");
            }

            // Close the statement
            $stmt->close();
        } else {
            header("Location: error.php");
        }
?>