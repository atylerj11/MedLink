<?php 

    session_start();

    // Check if the user is logged in
    if (isset($_SESSION['username'])) {
      $usernameSession = $_SESSION['username'];
    } else {
      // Redirect to the login page if the user is not logged in
      header("Location: login.html");
    }

    // Connection to database
    $server = 'localhost';
    $username = 'SeniorProjects';
    $password = 'Password';
    $db = 'MedLink';

    $conn = new mysqli($server, $username, $password, $db);

    if ($conn->connect_error) {
        die("Fatal Error: Database Connection");
    }

    //query changed to using username
    $queryResult = mysqli_query($conn, "SELECT * FROM userid WHERE username = '$usernameSession'");
    //store querry into an array
    $row = mysqli_fetch_assoc($queryResult);
 ?>

<!DOCTYPE html>
<html>
<head>
    <title>Med Link Doctor Homepage</title>
    <link rel="stylesheet" href="doclayout.css">
    <link rel="stylesheet" href="doc_homepage.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
</head>
<body>
    <!-- Top Nav Bar -->
    <header>
        <a href="doc_homepage.php"><img class="logo" src="img/MedLink_Logo.png" alt="logo"></a>
        <nav>
            <ul class="nav_buttons">
                <li><a href="doc_calendar.php"><span class="material-icons">calendar_month</span>Calendar</a></li>
                <li><a href="doc_view_prescription.php"><span class="material-icons">medication</span>Medication</a></li>
                <li><a href="doc_patient.php"><span class="material-icons">man</span>Patients</a></li>
                <li><a href="doc_message.php"><span class="material-icons">mail</span>Message</a></li>
            </ul>
        </nav>
        <a href="#" class="menu-icon" onclick="toggleDropdown()"><span class="material-icons">menu</span></a>
        <div class="dropdown_menu">
            <span class="close-icon" onclick="toggleDropdown()">&times;</span>
            <li class="hidden"><a href="doc_calendar.php"><span class="material-icons">calendar_month</span>Calender</a></li>
            <li class="hidden"><a href="doc_view_prescription.php"><span class="material-icons">medication</span>Medication</a></li>
            <li class="hidden"><a href="doc_patient.php"><span class="material-icons">man</span>Patients</a></li>
            <li class="hidden"><a href="#"><span class="material-icons">mail</span>Message</a></li>
            <li><a href="Contact_Us.php"><span class="material-icons">call</span>Contact us</a></li>
            <li><a href="logout.php"><span class="material-icons">logout</span>Logout</a></li>
        </div>
    </header>
    <script>
        const togglebtn = document.querySelector('.menu-icon')
        const dropdownMenu = document.querySelector(".dropdown_menu")

        function toggleDropdown() {
            dropdownMenu.classList.toggle('open');
            // Toggle the menu icon between "menu" and "close"
            const menuIcon = document.querySelector('.menu-icon .material-icons');
            menuIcon.textContent = menuIcon.textContent === 'menu' ? 'close' : 'menu';
        }
    </script>

   <!-- Body of Page -->
    <main>
        <!-- Left Side -->
        <div class="container1">
            <div class="con_welcome">
                <div class="welcome">Welcome back</div>
                <div class="name">Dr. 
                    <?php 
                        //get value from array under LastNameField
                        echo "{$row['LastName']}";
                    ?>
                    </div>
            </div>
            <div class="upcoming">Today's Upcoming Appointments</div>
            <div class="con_appointment">
                <!-- initiation of php loop to generate appointment cards -->
                <?php 
                
                // SQL query to retrieve patient information
                    $sql = "SELECT FirstName, LastName, Date, Time, CONCAT(Date, ' ', Time) as 'Chrono' FROM patient JOIN appointment ON patient.patientid = appointment.patientID WHERE DoctorID = (SELECT DoctorID FROM Doctor JOIN UserId ON userid.userid = doctor.userid WHERE username = '$usernameSession') AND DATE = CURDATE() order by Chrono";
                    $result = $conn->query($sql);

                    if ($result === false) {
                        // Query execution failed
                        echo "Error: " . $conn->error;
                    } else {
                        
                        if($result->num_rows == 0){
                            ?>
                            <!-- Patient Card -->
                            <div class="card">
                                <div class="info">
                                    <div class="name">
                                        <?php echo "No appointments for today."; ?>
                                    </div>
                                </div>
                            </div>
                            <?php
                        }

                        while ($row = $result->fetch_assoc()) {
                            // Display patient information for each row
                            ?>
                            <!-- Patient Card -->
                            <div class="card">
                                <div class="info">
                                    <div class="name">
                                        <?php echo $row["FirstName"] . " " . $row["LastName"]; ?>
                                    </div>
                                    <div class="time">
                                        <?php echo $row["Date"] . " at " . $row["Time"]; ?>
                                    </div>
                                </div>
                            </div>
                            <?php
                        }
                    }

                        // Close the database connection
                        $conn->close();
                ?>
                <!-- end php loop -->
            </div>
        </div>
        <!-- Right Side -->
        <div class="container2">
            <nav>
                <li><a href="doc_create_prescription.php" class="green">Create Patient<br>Prescription</a></li>
                <li><a href="doc_summary.php" class="white">Create Appointment<br>Summary</a></li>
                <li><a href="doc_refill_requests.php" class="green">Manage Refill<br>Requests</a></li>
                <li><a href="doc_patient.php" class="white">Manage Patient Info</a></li>    
            </nav>
        </div>
        
    </main>

    <!-- Bottom Nav Bar -->
    <footer>
        <ul class="nav_buttons">
            <li><a href="Rules_Of_Conduct.php">Rules of Conduct</a></li>
            <li><a href="Privacy_Policy.php">Privacy Policy</a></li>
            <li><a href="FAQ.php">Need Help?</a></li>
        </ul>
    </footer>
</body>
</html> 