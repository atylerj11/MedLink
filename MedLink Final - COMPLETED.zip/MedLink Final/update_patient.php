<?php
    // connection to the database
    $server = 'localhost';
    $username = 'SeniorProjects';
    $password = 'Password';
    $db = 'MedLink';
    $conn = new mysqli($server, $username, $password, $db);

    if ($conn->connect_error) {
        die("Fatal Error: Database Connection");
    }

    // Check if PatientID is set
    if (isset($_POST['PatientID'])) {
        $PatientID = $_POST['PatientID'];
        
        // Check if other variables are set
        if (isset($_POST['Gender'], $_POST['EmergencyName'], $_POST['EmergencyNamePhoneNumber'], $_POST['Allergies'], $_POST['Conditions'], $_POST['ExistingIllnesses'], $_POST['BloodPressure'], $_POST['SugarLevels'])) {
            $Gender = $_POST['Gender'];
            $EmergencyName = $_POST['EmergencyName'];
            $EmergencyPhone = $_POST['EmergencyNamePhoneNumber'];
            $Allergies = $_POST['Allergies'];
            $Conditions = $_POST['Conditions'];
            $ExistingIllnesses = $_POST['ExistingIllnesses'];
            $BloodPressure = $_POST['BloodPressure'];
            $SugarLevels = $_POST['SugarLevels'];

            // Prepare and bind the update query
            $updateQuery = $conn->prepare("UPDATE Patient SET Gender = ?, EmergencyName = ?, EmergencyPhoneNumber = ?, Allergies = ?, Conditions = ?, ExistingIllnesses = ?, BloodPressure = ?, SugarLevels = ? WHERE PatientID = ?");
            $updateQuery->bind_param("ssssssssi", $Gender, $EmergencyName, $EmergencyPhone, $Allergies, $Conditions, $ExistingIllnesses, $BloodPressure, $SugarLevels, $PatientID);

            if ($updateQuery->execute()) {
                header("Location: success.php?success=3");
            } else {
                header("Location: error.php?error=7");
            }
        } else {
            header("Location: error.php?error=7");
        }
    } else {
        header("Location: error.php?error=7");
    }

    $conn->close();
?>