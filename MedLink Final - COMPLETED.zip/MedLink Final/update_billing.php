<?php
// Connection to the database
$server = 'localhost';
$username = 'SeniorProjects';
$password = 'Password';
$db = 'MedLink';
$conn = new mysqli($server, $username, $password, $db);

if ($conn->connect_error) {
    die("Fatal Error: Database Connection");
}

// Check if PatientID is set
if (isset($_POST['PatientID'])) {
    $PatientID = $_POST['PatientID'];

    // Check if other variables are set
    if (isset($_POST['details'], $_POST['insurancename'], $_POST['insurancenumber'], $_POST['Address'], $_POST['creditnumber'])) {
        $details = $_POST['details'];
        $insurancename = $_POST['insurancename'];
        $insurancenumber = $_POST['insurancenumber'];
        $Address = $_POST['Address'];
        $creditnumber = $_POST['creditnumber'];

        // Prepare and bind the update query
        $updateQuery = $conn->prepare("UPDATE Billing SET details = ?, insurancename = ?, insurancenumber = ?, Address = ?, creditnumber = ? WHERE PatientID = ?");
        $updateQuery->bind_param("ssssii", $details, $insurancename, $insurancenumber, $Address, $creditnumber, $PatientID);

        // Check for query execution success
        if ($updateQuery->execute()) {
            header("Location: success.php?success=12");
        } else {
            header("Location: error.php?error=16");
        }
    } else {
        header("Location: error.php?error=17");
    }
} else {
    header("Location: error.php?error=16");
}

$conn->close();
?>