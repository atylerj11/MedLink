<?php

     // Session Code
     session_start();

     // Check if the user is logged in
     if (isset($_SESSION['username'])) {
       $usernameSession = $_SESSION['username'];
     }
 
     // Connection to database
     $server = 'localhost';
     $username = 'SeniorProjects';
     $password = 'Password';
     $db = 'MedLink';
 
     $conn = new mysqli($server, $username, $password, $db);
 
     if ($conn->connect_error) {
         die("Fatal Error: Database Connection");
     }
    
        

    $conn->close();
 ?>

<!DOCTYPE html>
<html>
<head>
    <title>Privacy Policy</title>
    <link rel="stylesheet" href="Privacy_Policy.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
</head>
<body>
    <div class="container1">
        <img class="logo" src="img/MedLink_Logo.png" alt="logo">
        ,<h1>Privacy Policy</h1>
    </div>
    <div class="container2">
        <p> MedLink does collect information from its users. Here is the breakdown of what information MedLink gathers and what is it used for:<br><br>
            
        <b>Personal Accounts:</b> When creating your personal account in the MedLink system, we collect information on you to provide you our services. 
        Some of this information is sensitive such as your first and last name, and some is less sensitive like email and username. <br><br>

        <b>Payment Information:</b> While we do not collect payment information on our patient portal, we do store insurance information that patients provide to us directly,
        or that secretaries upload into our systems with patient consent.<br><br>

        <b>Settings:</b> When you set or change your settings, we collect that info so that we can better tune your experience to your preferences.<br><br>

        <b>Cookies and similar technologies:</b> Our website, like many others, utilizes cookies and similar technologies to collect additional website 
        usage data and operate our systems.

              </p>
    </div>
    <div class="container3"> 
    <a href="javascript:history.back()">Go Back</a>
    </div>
</body>
</html> 