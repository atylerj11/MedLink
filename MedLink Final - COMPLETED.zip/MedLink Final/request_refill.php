<?php
    // Connection to database
        $server = 'localhost';
        $username = 'SeniorProjects';
        $password = 'Password';
        $db = 'MedLink';

        $conn = new mysqli($server, $username, $password, $db);

        if ($conn->connect_error) {
            die("Fatal Error: Database Connection");
        }

        if (isset($_POST['prescriptionID'])) {
            $prescriptionID = $_POST['prescriptionID'];
        }

        // SQL query to insert the prescription into the "prescriptions" table
        $sql = "UPDATE prescription SET Status = 'Refill Requested' WHERE prescriptionID = ?;";

        // Prepare the SQL statement
        $stmt = $conn->prepare($sql);

        if ($stmt) {
            // Bind the parameters and execute the query
            $stmt->bind_param("s", $prescriptionID);
            if ($stmt->execute()) {
                header("Location: success.php?success=4");
            } else {
                header("Location: error.php?error=8");
            }

            // Close the statement
            $stmt->close();
        } else {
            header("Location: error.php");
        }
    ?>