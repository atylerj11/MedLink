<?php 
    // Session Code
    session_start();

    // Check if the user is logged in
    if (isset($_SESSION['username'])) {
      $usernameSession = $_SESSION['username'];
    } else {
      // Redirect to the login page if the user is not logged in
      header("Location: login.html");
    }

    // Connection to database
    $server = 'localhost';
    $username = 'SeniorProjects';
    $password = 'Password';
    $db = 'MedLink';

    $conn = new mysqli($server, $username, $password, $db);

    if ($conn->connect_error) {
        die("Fatal Error: Database Connection");
    }

    if (!(isset($_POST['update']))) {
        echo "Error with recipient";
    }
    else {
        $patient = $_POST['update'];
    }

    $sql = "SELECT * FROM patient WHERE PatientID = $patient";
    $result = $conn->query($sql);
    
    $row = $result->fetch_assoc();

    $gender = htmlspecialchars($row['Gender']);
    $eName = htmlspecialchars($row['EmergencyName']);
    $eNumber = htmlspecialchars($row['EmergencyPhoneNumber']);
    $allergies = htmlspecialchars($row['Allergies']);
    $conditions = htmlspecialchars($row['Conditions']);
    $illnesses = htmlspecialchars($row['ExistingIllnesses']);
    $blood = htmlspecialchars($row['BloodPressure']);
    $sugar = htmlspecialchars($row['SugarLevels']);

    $conn->close();
 ?>
<!DOCTYPE html>
<html>
<head>
    <title>Doctor Update Patient</title>
    <link rel="stylesheet" href="DocLayout.css">
    <link rel="stylesheet" href="doc_update_patient.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
</head>
<body>
   <!-- Top Nav Bar -->
   <header>
        <a href="doc_homepage.php"><img class="logo" src="img/MedLink_Logo.png" alt="logo"></a>
        <nav>
            <ul class="nav_buttons">
                <li><a href="doc_calendar.php"><span class="material-icons">calendar_month</span>Calendar</a></li>
                <li><a href="doc_view_prescription.php"><span class="material-icons">medication</span>Medication</a></li>
                <li><a href="doc_patient.php"><span class="material-icons">man</span>Patients</a></li>
                <li><a href="doc_message.php"><span class="material-icons">mail</span>Message</a></li>
            </ul>
        </nav>
        <a href="#" class="menu-icon" onclick="toggleDropdown()"><span class="material-icons">menu</span></a>
        <div class="dropdown_menu">
            <span class="close-icon" onclick="toggleDropdown()">&times;</span>
            <li class="hidden"><a href="doc_calendar.php"><span class="material-icons">calendar_month</span>Calender</a></li>
            <li class="hidden"><a href="doc_view_prescription.php"><span class="material-icons">medication</span>Medication</a></li>
            <li class="hidden"><a href="doc_patient.php"><span class="material-icons">man</span>Patients</a></li>
            <li class="hidden"><a href="#"><span class="material-icons">mail</span>Message</a></li>
            <li><a href="Contact_Us.php"><span class="material-icons">call</span>Contact us</a></li>
            <li><a href="logout.php"><span class="material-icons">logout</span>Logout</a></li>
        </div>
    </header>
    <script>
        const togglebtn = document.querySelector('.menu-icon')
        const dropdownMenu = document.querySelector(".dropdown_menu")

        function toggleDropdown() {
            dropdownMenu.classList.toggle('open');
            // Toggle the menu icon between "menu" and "close"
            const menuIcon = document.querySelector('.menu-icon .material-icons');
            menuIcon.textContent = menuIcon.textContent === 'menu' ? 'close' : 'menu';
        }
    </script>

   <!-- Body of Page -->
    <main>
        <!-- Name -->
        <div class="header">Updating <?php echo "{$row['FirstName']}";?></div>
        <div class="content">
            <!-- Update Form -->
            <form class="card" action="update_patient.php" method="post">
                <!-- Gender -->
                <div class="inputArea">
                    <input type="text" class="inputField" name="Gender" value="<?php echo $gender;?>" placeholder="" >
                    <label class="label">Gender</label>
                    <span class="bottomBorder"></span>
                    <span class="bar"></span>
                </div>
                <!-- Emergency Contact -->
                <div class="inputArea">
                    <input type="text" class="inputField" name="EmergencyName" value="<?php echo $eName;?>" placeholder="" >
                    <label class="label">Emergency Contact</label>
                    <span class="bottomBorder"></span>
                    <span class="bar"></span>
                </div>
                <!-- Emergency Contact #-->
                <div class="inputArea">
                    <input type="text" class="inputField" name="EmergencyNamePhoneNumber" value="<?php echo $eNumber;?>" placeholder="" >
                    <label class="label">Emergency Contact #</label>
                    <span class="bottomBorder"></span>
                    <span class="bar"></span>
                </div>
                <!-- Allergies-->
                <div class="inputArea">
                    <input type="text" class="inputField" name="Allergies" value="<?php echo $allergies;?>" placeholder="" >
                    <label class="label">Allergies</label>
                    <span class="bottomBorder"></span>
                    <span class="bar"></span>
                </div>
                <!-- Conditions -->
                <div class="inputArea">
                    <input type="text" class="inputField" name="Conditions" value="<?php echo $conditions;?>" placeholder="" >
                    <label class="label">Conditions</label>
                    <span class="bottomBorder"></span>
                    <span class="bar"></span>
                </div>
                <!-- Existing Illnesses -->
                <div class="inputArea">
                    <input type="text" class="inputField" name="ExistingIllnesses"  value="<?php echo $illnesses;?>" placeholder="" >
                    <label class="label">Existing Illnesses</label>
                    <span class="bottomBorder"></span>
                    <span class="bar"></span>
                </div>
                <!-- Blood Pressure -->
                <div class="inputArea">
                    <input type="text" class="inputField" name="BloodPressure" value="<?php echo $blood;?>" placeholder="" >
                    <label class="label">Blood Pressure</label>
                    <span class="bottomBorder"></span>
                    <span class="bar"></span>
                </div>
                <!-- Sugar Levels -->
                <div class="inputArea">
                    <input type="text" class="inputField" name="SugarLevels" value="<?php echo $sugar;?>" placeholder="" >
                    <label class="label">Sugar Levels</label>
                    <span class="bottomBorder"></span>
                    <span class="bar"></span>
                </div>
                <!-- Submit BUtton -->
                <button type="submit" name="PatientID" value="<?php echo $row['PatientID'];?>">Update Patient</button>
            </form>
        </div>
    </main>

    <!-- Bottom Nav Bar -->
    <footer>
        <ul class="nav_buttons">
            <li><a href="Rules_Of_Conduct.php">Rules of Conduct</a></li>
            <li><a href="Privacy_Policy.php">Privacy Policy</a></li>
            <li><a href="FAQ.php">Need Help?</a></li>
        </ul>
    </footer>
</body>
</html>
