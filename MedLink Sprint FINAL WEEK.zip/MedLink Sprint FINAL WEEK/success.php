<?php

     // Session Code
     session_start();

     // Check if the user is logged in
     if (isset($_SESSION['username'])) {
       $usernameSession = $_SESSION['username'];
     }
 
     // Connection to database
     $server = 'localhost';
     $username = 'SeniorProjects';
     $password = 'Password';
     $db = 'MedLink';
 
     $conn = new mysqli($server, $username, $password, $db);
 
     if ($conn->connect_error) {
         die("Fatal Error: Database Connection");
     }

    //gets what error is sent to the page
    if (isset($_GET['success'])) {
        $success = $_GET['success'];
    }
    else {
        $error = 0;
    }

    //compares gotten error, to errors page can display
    switch ($success) {
    case 1:
        $msg = "Registered successfully! Please go back to log in.";
        $link = "login.html";
        break;
    case 2:
        $msg = "Information successfully added! Please go back to continue.";
        $link = "doc_create_prescription.php";
        break;
    case 3:
        $msg = "Information successfully added! Please go back to continue.";
        $link = "doc_patient.php";
        break;
    case 4:
        $msg = "Request Sent! Please give the doctor a few days to review it.";
        $link = "patient_medication.php";
        break;
    case 5:
        $msg = "Appointment Successfully cancelled.";
        $link = "javascript:history.back()";
        break;
    case 6:
        $msg = "Appopintment Summary Created!";
        $link = "doc_summary.php";
        break;
    case 7:
        $msg = "File successfully uploaded to Tests!";
        $link = "doc_summary.php";
        break;
    case 8:
        $msg = "Diagnosis successfully added! Please go back to continue.";
        $link = "doc_summary.php";
        break;
    case 9:
        $msg = "Appointment created successfully! You may see it on your homepage. Please go back.";
        $link = "javascript:history.back()";
        break;
    case 10:
        $msg = "Prescription was renewed successfully. Please go back to continue.";
        $link = "doc_view_prescription.php";
        break;
    case 11:
        $msg = "Prescription was Denied. Please go back to continue.";
        $link = "doc_view_prescription.php";
        break;
    case 12:
        $msg = "Billing information successfully updated. Please go back to continue.";
        $link = "secretary_billing.php";
        break;
    case 13:
        $msg = "Patient successfully created. Please go back to continue.";
        $link = "create_patient_form.php";
        break;
    case 14:
        $msg = "Patient Billing Information successfully added. Please go back to continue.";
        $link = "secretary_billing.php";
        break;
    default:
        $msg = "Success! Please go back now.";
        $link = "#";
    }

    $conn->close();
 ?>

<!DOCTYPE html>
<html>
<head>
    <title>Success Page</title>
    <link rel="stylesheet" href="error.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
</head>
<body>
    <div class="container1">
        <img class="logo" src="img/MedLink_Logo.png" alt="logo">
        <img class="error" src="img/check.png" alt="error">
    </div>
    <div class="container2">
        <h1><?php echo $msg;?></h1>
        <a href="<?php echo $link; ?>">Go Back</a>
    </div>
</body>
</html> 