<?php 

    session_start();

    // Check if the user is logged in
    if (isset($_SESSION['username'])) {
    $usernameSession = $_SESSION['username'];
    } else {
    // Redirect to the login page if the user is not logged in
    header("Location: login.html");
    }

    // Connection to database
    $server = 'localhost';
    $username = 'SeniorProjects';
    $password = 'Password';
    $db = 'patientportal';

    $conn = new mysqli($server, $username, $password, $db);

    if ($conn->connect_error) {
        die("Fatal Error: Database Connection");
    }

    
    $queryResult = mysqli_query($conn, "SELECT * FROM userid WHERE username = '$usernameSession'");
    //store querry into an array
    $row = mysqli_fetch_assoc($queryResult);

    
 ?>

<!DOCTYPE html>
<html>
<head>
    <title>Med Link Patient Homepage</title>
    <link rel="stylesheet" href="layout.css">
    <link rel="stylesheet" href="patient_appointments.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
</head>
<body>
    <!-- Top Nav Bar -->
    <header>
        <a href="patient_homepage.php"><img class="logo" src="img/MedLink_Logo.png" alt="logo"></a>
        <nav>
            <ul class="nav_buttons">
                <li><a href="#"><span class="material-icons">calendar_month</span>Calender</a></li>
                <li><a href="patient_medication.php"><span class="material-icons">medication</span>Medication</a></li>
                <li><a href="#"><span class="material-icons">science</span>Results</a></li>
                <li><a href="#"><span class="material-icons">mail</span>Message</a></li>
            </ul>
        </nav>
        <a href="#"><span class="material-icons">menu</span></a>
    </header>
   
    <!-- Body of Page -->
    <main>
        <!-- Left Side -->
        <div class="container1">
            <div class="con_welcome">
                <div class="welcome">Welcome back</div>
                <div class="name">
                    <?php 
                        echo "{$row['FirstName']}";
                    ?>
                </div>
            </div>
            <div class="upcoming">Upcoming Appointments</div>
            <div class="con_appointment">
                <!-- initiation of php loop to generate appointment cards -->
                
                <?php 
                
                // SQL query to retrieve patient information
                    $sql = "SELECT doctor.FirstName, doctor.LastName, Date, Time FROM patient JOIN appointment ON patient.patientid = appointment.patientID JOIN doctor ON appointment.doctorid = doctor.doctorid WHERE patient.patientID = (SELECT patientID FROM patient JOIN UserId ON userid.userid = patient.userid WHERE username = '$usernameSession')";
                    $result = $conn->query($sql);

                    if ($result === false) {
                        // Query execution failed
                        echo "Error: " . $conn->error;
                    } else {
                        while ($row = $result->fetch_assoc()) {
                            // Display patient information for each row
                            ?>
                            <!-- Patient Card -->
                            <div class="card">
                                <div class="info">
                                    <div class="name">
                                        <?php echo "Dr. ".$row["FirstName"] . " " . $row["LastName"]; ?>
                                    </div>
                                    <div class="time">
                                        <?php echo $row["Date"] . " at " . $row["Time"]; ?>
        
                                    </div>
                                 
                                </div>
                                <div>
                                        <button type="button">Cancel Appointment</button> 
                            </div>
                            </div>
                            <?php
                        }
                    }

                        // Close the database connection
                        $conn->close();
                ?>
                
            </div>
        </div>
        <!-- Right Side -->
       
    
        <div class="container2">
             <nav>
                <li><a href="#" class="blue">Create Appointment</a></li>  
            </nav>
        </div>
        
    </main>

    <!-- Bottom Nav Bar -->
    <footer>
        <ul class="nav_buttons">
            <li><a href="Rules_Of_Conduct.php">Rules of Conduct</a></li>
            <li><a href="Privacy_Policy.php">Privacy Policy</a></li>
            <li><a href="FAQ.php">Need Help?</a></li>
        </ul>
    </footer>
</body>
</html> 