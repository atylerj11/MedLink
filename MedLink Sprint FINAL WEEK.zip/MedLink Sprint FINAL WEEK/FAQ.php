<?php

     // Session Code
     session_start();

     // Check if the user is logged in
     if (isset($_SESSION['username'])) {
       $usernameSession = $_SESSION['username'];
     }
 
     // Connection to database
     $server = 'localhost';
     $username = 'SeniorProjects';
     $password = 'Password';
     $db = 'MedLink';
 
     $conn = new mysqli($server, $username, $password, $db);
 
     if ($conn->connect_error) {
         die("Fatal Error: Database Connection");
     }
    
        

    $conn->close();
 ?>

<!DOCTYPE html>
<html>
<head>
    <title>Rules of Conduct</title>
    <link rel="stylesheet" href="FAQ.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
</head>
<body>
    <div class="container1">
        <img class="logo" src="img/MedLink_Logo.png" alt="logo">
        ,<h1>Privacy Policy</h1>
    </div>
    <div class="container2">
        <p> <b>Frequently Asked Questions (FAQ)</b><br><br>

        Welcome to the Patient Portal FAQ section. We've compiled a list of commonly asked questions to help you 
        navigate our patient portal and make the most of your healthcare experience. If you can't find the answer you're looking for, 
        feel free to contact our support team for further assistance.<br><br><br>


        
        <b>1. What is the Patient Portal?</b><br><br>

        The MedLink Patient Portal is an online platform that allows you to access your medical information, schedule appointments, 
        communicate with your healthcare provider, and more from the convenience of your computer.<br><br><br>



        <b>2. How do I sign up for the Patient Portal?</b><br><br>

        To sign up for MedLink, you will need to register by clicking the blue button at the bottom of the login page. This will take you to a seperate page that will 
        ask you for some information before allowing you to create your account. You can log in after registering.<br><br><br>



        <b>3. Is the Patient Portal secure?</b><br><br>

        Yes, we take the security of your personal health information seriously.
         Our portal is encrypted and compliant with all relevant healthcare data protection laws, such as HIPAA.<br><br><br>



         <b>4. What can I do in the Patient Portal?</b><br><br>
         In the Patient Portal, you can:<br>
         &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- View your medical records<br>
         &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Book appointments<br>
         &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Send secure messages to your &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;healthcare provider<br>
         &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Request prescription refills<br>
         &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Update patient info<br><br><br>



         <b>5. Can I pay my bills through the portal?</b><br><br>

         No you can not pay your bills through MedLink's patient portal, but we do link to a 3rd party website that handles
         payment.<br><br><br>



         <b>8. How do I communicate with my healthcare provider through the portal?</b><br><br>

         You can send a secure message to your healthcare provider through the "Messages" section of the portal. 
         This is a convenient way to ask questions, request information, or discuss your health concerns.<br><br><br>



         <b>9. How do I view my test results in the portal?</b><br><br>

         Once your healthcare provider has uploaded your test results, you can view them in the "Test Results" section of the portal.<br><br><br>



        <b>12. What if I encounter technical issues while using the portal?</b><br><br>

        If you experience technical difficulties, please reach out to our support team. They can assist you with any technical problems or questions you may have.
        <br><br><br>


        We hope these FAQs help you make the most of our Patient Portal. If you have any other questions or need assistance, please don't hesitate to contact us. Your health and satisfaction are our top priorities.
              </p>
    </div>
    <div class="container3"> 
    <a href="javascript:history.back()">Go Back</a>
    </div>
</body>
</html> 