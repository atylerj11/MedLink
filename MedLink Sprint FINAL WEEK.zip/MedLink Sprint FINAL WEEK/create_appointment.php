<?php
    session_start();

    // Check if the user is logged in
    if (isset($_SESSION['username'])) {
    $usernameSession = $_SESSION['username'];
    } else {
    // Redirect to the login page if the user is not logged in
    header("Location: login.html");
    }

    // Connection to database
    $server = 'localhost';
    $username = 'SeniorProjects';
    $password = 'Password';
    $db = 'MedLink';

    $conn = new mysqli($server, $username, $password, $db);

    if ($conn->connect_error) {
        die("Fatal Error: Database Connection");
    }

    if (isset($_POST['PatientID'])) {
        $PatientID = $_POST['PatientID'];
    }
    if (isset($_POST['DoctorID'])) {
        $DoctorID = $_POST['DoctorID'];
    }
    if (isset($_POST['Date'])) {
        $Date = $_POST['Date'];
    }
    if (isset($_POST['Time'])) {
        $Time = $_POST['Time'];
    }
    if (isset($_POST['Type'])) {
        $Type = $_POST['Type'];
    }

    $checkQuery =  $conn->prepare("SELECT DoctorID, Date, Time FROM Appointment WHERE DoctorID = ? AND Date = ? AND Time = ?");
    $checkQuery->bind_param("sss", $DoctorID, $Date, $Time);
    $checkQuery->execute();
    $checkQuery = $checkQuery->get_result();

    if ($checkQuery->num_rows > 0) {

        header("Location: error.php?error=13");

    } else {

        $insertQuery = $conn->prepare("INSERT INTO appointment (AppointmentID,PatientID, DoctorID, Date, Time, Type, AppointmentSummary) VALUES (NULL,?, ?, ?, ?, ?, 'No Summary Added')");
        if (!$insertQuery) {
            die("Error: " . $conn->error);
        }

        // Bind the parameters
        $insertQuery->bind_param("sssss", $PatientID, $DoctorID, $Date, $Time, $Type);

        // Execute the statement
        if ($insertQuery->execute()) {
            header("Location: success.php?success=9");
        } else {
            header("Location: error.php?error=14");
        }

        // Close the prepared statement and the database connection
        $insertQuery->close();

        // Close the statement
        $stmt->close();
    }
    
    $conn->close();
    
?>