<?php 
    // Session Code
    session_start();

    // Check if the user is logged in
    if (isset($_SESSION['username'])) {
      $usernameSession = $_SESSION['username'];
    } else {
      // Redirect to the login page if the user is not logged in
      header("Location: login.html");
    }

    // Connection to database
    $server = 'localhost';
    $username = 'SeniorProjects';
    $password = 'Password';
    $db = 'MedLink';

    $conn = new mysqli($server, $username, $password, $db);

    if ($conn->connect_error) {
        die("Fatal Error: Database Connection");
    }
 ?>

<!DOCTYPE html>
<html>
<head>
    <title>Med Link Billing Information</title>
    <link rel="stylesheet" href="secretary_layout.css">
    <link rel="stylesheet" href="secretary_billing.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

<script>
//search for patient info to fill in more info card
function patient_info(patient) {
    // Checks if the info card is hidden or visible, if it is, sets it to be visible
    var infoCard = document.getElementById("infoCard");
    if (window.getComputedStyle(document.getElementById("infoCard")).display === "none") {
        infoCard.style.display = "flex";
    }

    //sends the patientid to php script to get patient info
    fetch('php_functions.php?billingInfoFilter=' + patient)
        .then(response => response.json())
        .then(data => {
            // Store the data in an associative array
            let billingData = data;
            // console.log(prescriptionData); // Outputs to the console for debugging
            // Each line fills in relevant HTML area with information stored in the array from the PHP script
            document.getElementById("name").textContent = billingData.FirstName + " " + billingData.LastName
            document.getElementById("details").textContent = billingData.details;
            document.getElementById("insurancename").textContent = billingData.insurancename;
            document.getElementById("insurancenumber").textContent = billingData.insurancenumber;
            document.getElementById("Address").textContent = billingData.Address;
            document.getElementById("creditnumber").textContent = billingData.creditnumber;
        });


    // Search through prescription cards
    function searchPatient() {
    var search = document.getElementById("search").value.toLowerCase();
    var cards = document.getElementsByClassName("card");

    for (var i = 0; i < cards.length; i++) {
            var drugName = cards[i].getElementsByClassName("patientName")[0].textContent.toLowerCase();
            if (drugName.includes(search)) {
                cards[i].style.display = "flex";
            } else {
                cards[i].style.display = "none";
            }
    }
}

}

//search through patient cards
function searchPatients() {
    var search = document.getElementById("search").value.toLowerCase();
    var cards = document.getElementsByClassName("card");

    for (var i = 0; i < cards.length; i++) {
            var name = cards[i].getElementsByClassName("name")[0].textContent.toLowerCase();
            if (name.includes(search)) {
                cards[i].style.display = "flex";
            } else {
                cards[i].style.display = "none";
            }
    }
}
</script>

</head>
<body>
   <!-- Top Nav Bar -->
   <header>
        <a href="secretary_homepage.php"><img class="logo" src="img/MedLink_Logo.png" alt="logo"></a>
        <nav>
            <ul class="nav_buttons">
                <li><a href="secretary_appointments.php"><span class="material-icons">calendar_month</span>Appointments</a></li>
                <li><a href="secretary_create_appointments.php"><span class="material-icons">edit_note</span>Create Appointment</a></li>
                <li><a href="secretary_billing.php"><span class="material-icons">payments</span>Billing Information</a></li>
            </ul>
        </nav>
        <a href="#" class="menu-icon" onclick="toggleDropdown()"><span class="material-icons">menu</span></a>
        <div class="dropdown_menu">
            <span class="close-icon" onclick="toggleDropdown()">&times;</span>
            <li class="hidden"><a href="secretary_appointments.php"><span class="material-icons">calendar_month</span>Appointments</a></li>
            <li class="hidden"><a href="secretary_create_appointments.php"><span class="material-icons">edit_note</span>Create Appointment</a></li>
            <li class="hidden"><a href="secretary_billing.php"><span class="material-icons">payments</span>Billing Information</a></li>
            <li><a href="#"><span class="material-icons">call</span>Contact us</a></li>
            <li><a href="logout.php"><span class="material-icons">logout</span>Logout</a></li>
        </div>
    </header>
    <script>
        const togglebtn = document.querySelector('.menu-icon')
        const dropdownMenu = document.querySelector(".dropdown_menu")

        function toggleDropdown() {
            dropdownMenu.classList.toggle('open');
            // Toggle the menu icon between "menu" and "close"
            const menuIcon = document.querySelector('.menu-icon .material-icons');
            menuIcon.textContent = menuIcon.textContent === 'menu' ? 'close' : 'menu';
        }
    </script>

   <!-- Body of Page -->
    <main>
        <div class="header">Patient List</div>
        <div class="content">
            <!-- Left Side -->
            <div class="container1">
                <div class="inputArea">
                    <input type="text" id="search" name="search" placeholder="" onkeyup="searchPatients()">
                    <label class="label">Search</label>
                    <span class="bottomBorder"></span>
                    <span class="bar"></span>
                </div>
                <div class="container2">
                     <!-- initiation of php loop to generate patient cards -->
                    <?php 
                        // SQL query to retrieve patient information
                        $sql = "SELECT PatientID, FirstName, LastName, FamilyID FROM patient";
                        $result = $conn->query($sql);

                        if ($result === false) {
                            // Query execution failed
                            echo "Error: " . $conn->error;
                        } else {
                            while ($row = $result->fetch_assoc()) {
                                // Display patient information for each row
                                ?>
                                <!-- Patient Card -->
                                <div class="card ">
                                    <div class="info">
                                        <div class="name">
                                            <?php echo $row["FirstName"] . " " . $row["LastName"]; ?>
                                        </div>
                                        <div class="family">
                                            <?php echo $row["FamilyID"]; ?>
                                        </div>
                                    </div>
                                    <div class="btn">
                                        <!-- makes a button and sends php variable of the cards patient to the JS function -->
                                        <form method="post" action="create_billing_form.php">
                                            <button type="submit" name="create" value="<?php echo $row['PatientID'];?>">Create Billing Info</button>
                                        </form>
                                        <form method="post" action="update_billing_form.php">
                                            <button type="submit" name="update" value="<?php echo $row['PatientID'];?>">Update Billing Info</button>
                                        </form>
                                        <button onclick="patient_info('<?php echo $row['PatientID']; ?>')">Click for More Info</button>
                                    </div>
                                </div>
                                <?php
                            }
                            $conn->close();
                        }
                    ?>
                </div>
            </div>
            <!-- Right Side -->
            <div class="container3">
                <div id="infoCard" class="patient">
                    <!-- Top of info Card -->
                    <div class="top">
                        <!-- Patient Info, filled in from JavaScript function-->
                        <div class="left_info">
                            <div>
                                <b><span id="name"></span></b>
                            </div>
                            <div>
                                <b>Details: </b><span id="details"></span>
                            </div>
                            <div>
                                <b>Insurance Name: </b><span id="insurancename"></span>
                            </div>
                            <div>
                                <b>Insurance Number: </b><span id="insurancenumber"></span>
                            </div>
                            <div>
                                <b>Address: </b><span id="Address"></span>
                            </div>
                            <div>
                                <b>Credit Number: </b><span id="creditnumber"></span>
                            </div>
                        </div>
                    </div>
                </div>        
            </div>
        </div>
    </main>

    <!-- Bottom Nav Bar -->
    <footer>
        <ul class="nav_buttons">
            <li><a href="Rules_Of_Conduct.php">Rules of Conduct</a></li>
            <li><a href="Privacy_Policy.php">Privacy Policy</a></li>
            <li><a href="FAQ.php">Need Help?</a></li>
        </ul>
    </footer>
</body>
</html> 