<?php
// Connection to the database
$server = 'localhost';
$username = 'SeniorProjects';
$password = 'Password';
$db = 'MedLink';

$conn = new mysqli($server, $username, $password, $db);

if ($conn->connect_error) {
    die("Fatal Error: Database Connection");
}

// Function to get patient name
function getPatientName($conn, $patientID)
{
    $sql = "SELECT CONCAT(FirstName, ' ', LastName) AS FullName FROM patient WHERE PatientID = $patientID";
    $result = $conn->query($sql);

    if ($result === false) {
        return "Error: " . $conn->error;
    }

    $row = $result->fetch_assoc();
    return $row['FullName'];
}

// Function to get doctor name
function getDoctorName($conn, $doctorID)
{
    $sql = "SELECT CONCAT(FirstName, ' ', LastName) AS FullName FROM doctor WHERE DoctorID = $doctorID";
    $result = $conn->query($sql);

    if ($result === false) {
        return "Error: " . $conn->error;
    }

    $row = $result->fetch_assoc();
    return $row['FullName'];
}

// Gets information from prescription table
if (isset($_GET['prescriptionFilter'])) {
    $filter = $_GET['prescriptionFilter'];

    // Select statement
    $sql = "SELECT prescription.PrescriptionID, prescription.PatientID, prescription.DoctorID, prescription.Name AS DrugName, prescription.Reason, prescription.Instructions, 
            CONCAT(patient.FirstName, ' ', patient.LastName) AS PatientName, 
            CONCAT(doctor.FirstName, ' ', doctor.LastName) AS DoctorName 
            FROM prescription
            JOIN patient ON prescription.PatientID = patient.PatientID
            JOIN doctor ON prescription.DoctorID = doctor.DoctorID
            WHERE PrescriptionID = $filter";
    $result = $conn->query($sql);

    if ($result === false) {
        echo "Error: " . $conn->error;
    }

    // Fetch data into an array
    $data = $result->fetch_assoc();

    // Return data as JSON for the JavaScript function
    header('Content-Type: application/json');
    echo json_encode($data);
}

// Close the database connection

?>