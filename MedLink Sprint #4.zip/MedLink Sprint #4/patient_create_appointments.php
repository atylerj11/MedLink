<?php 
    // Session Code
    session_start();

    // Check if the user is logged in
    if (isset($_SESSION['username'])) {
      $usernameSession = $_SESSION['username'];
    } else {
      // Redirect to the login page if the user is not logged in
      header("Location: login.html");
    }

    // Connection to database
    $server = 'localhost';
    $username = 'SeniorProjects';
    $password = 'Password';
    $db = 'MedLink';

    $conn = new mysqli($server, $username, $password, $db);

    if ($conn->connect_error) {
        die("Fatal Error: Database Connection");
    }
 ?>

<!DOCTYPE html>
<html>
<head>
    <title>Patient Message</title>
    <link rel="stylesheet" href="patient_create_appointments.css">
    <link rel="stylesheet" href="Layout.css">

    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
</head>
<body>
    <!-- Top Nav Bar -->
    <header>
        <a href="patient_homepage.php"><img class="logo" src="img/MedLink_Logo.png" alt="logo"></a>
        <nav>
            <ul class="nav_buttons">
                <li><a href="patient_medication.php"><span class="material-icons">medication</span>Medication</a></li>
                <li><a href="#"><span class="material-icons">science</span>Results</a></li>
                <li><a href="patient_message.php"><span class="material-icons">mail</span>Message</a></li>
            </ul>
        </nav>
        <a href="#" class="menu-icon" onclick="toggleDropdown()"><span class="material-icons">menu</span></a>
        <div class="dropdown_menu">
            <span class="close-icon" onclick="toggleDropdown()">&times;</span>
            <li class="hidden"><a href="patient_medication.php"><span class="material-icons">medication</span>Medication</a></li>
            <li class="hidden"><a href="#"><span class="material-icons">science</span>Results</a></li>
            <li class="hidden"><a href="patient_message.php"><span class="material-icons">mail</span>Message</a></li>
            <li><a href="#"><span class="material-icons">call</span>Contact us</a></li>
            <li><a href="logout.php"><span class="material-icons">logout</span>Logout</a></li>
        </div>
    </header>
    <script>
        const togglebtn = document.querySelector('.menu-icon')
        const dropdownMenu = document.querySelector(".dropdown_menu")

        function toggleDropdown() {
            dropdownMenu.classList.toggle('open');
            // Toggle the menu icon between "menu" and "close"
            const menuIcon = document.querySelector('.menu-icon .material-icons');
            menuIcon.textContent = menuIcon.textContent === 'menu' ? 'close' : 'menu';
        }
    </script>

   <!-- Body of Page -->
    <main>
        <div class="welcome">Create an Appointment</div>
        <div class="center_container";>
            <form method="post" action="create_appointment.php" onsubmit="return validate(this)">

                <!-- Patient -->
                <?php 
                    //query get patient data
                    $queryResult = mysqli_query($conn, "SELECT * FROM patient WHERE PatientID = (SELECT PatientID FROM patient join userid on userid.UserID = patient.UserID WHERE username = '$usernameSession')");
                    //store querry into an array
                    $row = mysqli_fetch_assoc($queryResult);
                ?>
                <div class="inputArea emailLine">
                    <input type="text"  class="inputField" name="PatientID" placeholder="" value="<?php echo $row['PatientID']; ?>" readonly required>
                    <label class="label">PatientID</label>
                    <span class="bottomBorder"></span>
                    <span class="bar"></span>
                </div>

                <!-- Doctor -->
                <label class="label2" for="doctorSelect">Doctor</label>
                <select name="DoctorID" class="doctor" id="doctorSelect">
                    <!-- initiation of php loop to generate doctors -->
                    <?php 
                        // SQL query to retrieve doctor list
                        $sql = "SELECT * FROM doctor";
                        $result = $conn->query($sql);

                        if ($result === false) {
                            // Query execution failed
                            echo "Error: " . $conn->error;
                        } 
                        else {
                            while ($row = $result->fetch_assoc()) {
                                // Display doctor options, value is doctorid and the last name is displayed
                                ?>
                                    <option value="<?php echo $row['doctorid'] ?>"><?php echo 'Dr. ' . $row['LastName'] ?></option>
                                <?php
                            }
                        }
                    // Close the database connection
                     $conn->close(); 
                    ?>
                </select>

                <!-- Date -->
                <div class="inputArea emailLine">
                    <label class="label2" for="dateSelect">Date</label>
                    <input class="date" id="dateSelect" type="date" name="Date"/>
                    <!-- <input type="text"  class="inputField" name="Date" placeholder="" required>
                    <label class="label">Date</label>
                    <span class="bottomBorder"></span>
                    <span class="bar"></span> -->
                </div>

                <!-- Time -->
                <label class="label2" for="timeSelect">Time</label>
                <select name="Time" id="timeSelect">
                    <!-- initiation of php loop to generate times -->
                    <?php
                        // choosing start time and end time, 8am to 5pm
                        $start = strtotime('08:00');
                        $end   = strtotime('17:00');
                        //loop, adds 60 seconds 30 times(30 mins) to the counter, which starts at start time and ends at end time.
                        for ($i = $start; $i <= $end; $i = $i + (60 * 30)) { ?>
                            <!-- option creation, sets value and display of options, uses date() to format counter, 
                            g = 12 hour format, i = mins with leading 0s, A = uppercase AM/PM-->
                            <option value="<?php echo date('G:i', $i) ?>"> <?php echo date('G:i', $i) ?> </option>
                        <?php }
                    ?>
                </select>

                <!-- Type -->
                <div class="inputArea emailLine">
                    <input type="text"  class="inputField" name="Type" placeholder="" required>
                    <label class="label">Type</label>
                    <span class="bottomBorder"></span>
                    <span class="bar"></span>
                </div>
                
                <input class ="btn" type="submit" value="Create Appointment">
                
            </form>
        </div>
    </main>

    <!-- Bottom Nav Bar -->
    <footer>
        <ul class="nav_buttons">
            <li><a href="#">Rules of Conduct</a></li>
            <li><a href="#">Privacy Policy</a></li>
            <li><a href="#">Need Help?</a></li>
        </ul>
    </footer>
</body>
</html> 