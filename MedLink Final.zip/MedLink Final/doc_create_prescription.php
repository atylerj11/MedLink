<?php
    session_start();

    // Check if the user is logged in
    if (isset($_SESSION['username'])) {
    $usernameSession = $_SESSION['username'];
    } else {
    // Redirect to the login page if the user is not logged in
    header("Location: login.html");
    }


    $server = 'localhost';
    $username = 'SeniorProjects';
    $password = 'Password';
    $db = 'MedLink';

    $conn = new mysqli($server, $username, $password, $db);

    if ($conn->connect_error) {
        die("Fatal Error: Database Connection");
    }

    //query changed to using username
    $queryResult = mysqli_query($conn, "SELECT DoctorID FROM Doctor WHERE UserID = (SELECT UserID FROM UserID WHERE username = '$usernameSession')" );
    //store querry into an array
    $row = mysqli_fetch_assoc($queryResult);
?>


<!DOCTYPE html>
<html>
<head>
    <title>Create prescriptions</title>
    <link rel="stylesheet" href="Doc_Create_prescription.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
    <!-- Top Nav Bar -->
    <header>
        <a href="doc_homepage.php"><img class="logo" src="img/MedLink_Logo.png" alt="logo"></a>
        <nav>
            <ul class="nav_buttons">
            <li><a href="doc_calendar.php"><span class="material-icons">calendar_month</span>Calendar</a></li>
                <li><a href="doc_view_prescription.php"><span class="material-icons">medication</span>Medication</a></li>
                <li><a href="doc_patient.php"><span class="material-icons">man</span>Patients</a></li>
                <li><a href="doc_message.php"><span class="material-icons">mail</span>Message</a></li>
            </ul>
        </nav>
        <a href="#" class="menu-icon" onclick="toggleDropdown()"><span class="material-icons">menu</span></a>
        <div class="dropdown_menu">
            <span class="close-icon" onclick="toggleDropdown()">&times;</span>
            <li class="hidden"><a href="doc_calendar.php"><span class="material-icons">calendar_month</span>Calender</a></li>
            <li class="hidden"><a href="doc_create_prescription.php"><span class="material-icons">medication</span>Medication</a></li>
            <li class="hidden"><a href="doc_patient.php"><span class="material-icons">man</span>Patients</a></li>
            <li class="hidden"><a href="#"><span class="material-icons">mail</span>Message</a></li>
            <li><a href="Contact_Us.php"><span class="material-icons">call</span>Contact us</a></li>
            <li><a href="logout.php"><span class="material-icons">logout</span>Logout</a></li>
        </div>
    </header>
    <script>

        const togglebtn = document.querySelector('.menu-icon')
        const dropdownMenu = document.querySelector(".dropdown_menu")

        function toggleDropdown() {
            dropdownMenu.classList.toggle('open');
            // Toggle the menu icon between "menu" and "close"
            const menuIcon = document.querySelector('.menu-icon .material-icons');
            menuIcon.textContent = menuIcon.textContent === 'menu' ? 'close' : 'menu';
        }

    // Function to populate the patient dropdown
    function populatePatients() {
        const patientDropdown = document.getElementById("patient");
        
        // Make an AJAX request to fetch patient data
        fetch("get_patients.php")
            .then(response => response.json())
            .then(data => {
                // Clear existing options
                patientDropdown.innerHTML = "";
                
                // Populate the dropdown with fetched data
                data.forEach(patient => {
                    const option = document.createElement("option");
                    option.value = patient.PatientID; // Concatenate first name and last name
                    option.textContent = patient.FirstName + " " + patient.LastName;
                    patientDropdown.appendChild(option);
                });
            })
            .catch(error => {
                console.error("Error fetching patient data: " + error);
            });
    }

        // Call the populatePatients function when the page loads
        window.onload = populatePatients;
    </script>

    <!-- Body of Page -->
    <main>
        <form class="Main_containers" action="insert_prescription.php" method="post">
            <div class="right_container">
                <div class="Top_container">
                    <h1>Create Prescriptions</h1>
                    <input type="text" name="prescription">
                    
                    <select name="patient" id="patient">
                        
                    </select>
                </div>
                <div class="bottom_container">
                    <h1>Create Prescription?</h1>
                    <button class="button btn1" type="submit" name="doctorid" value="<?php echo "{$row['DoctorID']}";?>">Yes</button>
                </div>    

            </div>
            <div class="left_container">
                <div class="textField">
                    <input type="text" name="reason" id="reason" required>
                    <span></span>
                    <label>Reason for Medication...</label>
                </div>
                <div class="textField">
                    <input type="text" name="instructions" id="instructions" required>
                    <span></span>
                    <label>How Medication Should be Taken...</label>
                </div>
            </div>
        </form>
    </main>

    <!-- Bottom Nav Bar -->
    <footer>
        <ul class="nav_buttons">
            <li><a href="Rules_Of_Conduct.php">Rules of Conduct</a></li>
            <li><a href="Privacy_Policy.php">Privacy Policy</a></li>
            <li><a href="FAQ.php">Need Help?</a></li>
        </ul>
    </footer>
</body>
</html>
