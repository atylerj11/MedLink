<?php 
    // Connection to database
    $server = 'localhost';
    $username = 'SeniorProjects';
    $password = 'Password';
    $db = 'MedLink';

    $conn = new mysqli($server, $username, $password, $db);

    if ($conn->connect_error) {
        die("Fatal Error: Database Connection");
    }
    
    // gets information from patient table
    if (isset($_GET['moreInfoFilter'])) {
        $filter = $_GET['moreInfoFilter'];

        // select statement
        $sql = "SELECT * FROM patient WHERE PatientID = $filter";
        $result = $conn->query($sql);

        if ($result === false) {
            // Query execution failed
            echo "Error: " . $conn->error;
        }

        // Fetch data into an array
        $data = array();
        while ($row = $result->fetch_assoc()) {
            $data = $row;
        }

        // Return data as JSON for the javascript function
        header('Content-Type: application/json');
        echo json_encode($data);
    }

    // gets information from prescription table
    if (isset($_GET['drugFilter'])) {
        $filter = $_GET['drugFilter'];

        // select statement
        $sql = "SELECT * FROM prescription WHERE PatientID = $filter";
        $result = $conn->query($sql);

        if ($result === false) {
            // Query execution failed
            echo "Error: " . $conn->error;
        }

        // Fetch data into an array
        $data = array();
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }

        // Return data as JSON for the javascript function
        header('Content-Type: application/json');
        echo json_encode($data);
    }

    // gets information from appointment table
    if (isset($_GET['visitFilter'])) {
        $filter = $_GET['visitFilter'];

        // select statement, checking for patientid, on or past current date and ordered by date, then only get 1
        $sql = "SELECT * FROM appointment 
        WHERE PatientID = $filter
        AND `Date` >= CURRENT_DATE()
        ORDER BY `Date`  ASC
        LIMIT 1";
        $result = $conn->query($sql);

        if ($result === false) {
            // Query execution failed
            echo "Error: " . $conn->error;
        }

        // Fetch data into an array
        $data = array();
        while ($row = $result->fetch_assoc()) {
            $data = $row;
        }

        // Return data as JSON for the javascript function
        header('Content-Type: application/json');
        echo json_encode($data);
    }

    if (isset($_GET['emailFilter'])) {
        $filter = $_GET['emailFilter'];

        // select statement, checking for patientid, on or past current date and ordered by date, then only get 1
        $sql = 
            "SELECT patient.PatientID, patient.FirstName, patient.LastName, userid.email
            FROM patient 
            JOIN userid 
            ON patient.UserID = userid.UserID
            WHERE patient.patientID = $filter";
        $result = $conn->query($sql);

        if ($result === false) {
            // Query execution failed
            echo "Error: " . $conn->error;
        }

        // Fetch data into an array
        $data = array();
        while ($row = $result->fetch_assoc()) {
            $data = $row;
        }

        // Return data as JSON for the javascript function
        header('Content-Type: application/json');
        echo json_encode($data);
    }


    if (isset($_GET['appointment']) && isset($_GET['usernameSession'])) {
        $filter = $_GET['appointment'];
        $usernameSession = $_GET['usernameSession'];
        // To prevent SQL injection, use prepared statements
        $stmt = $conn->prepare("SELECT Type, FirstName, LastName, Date, Time FROM patient JOIN appointment ON patient.patientid = appointment.patientID WHERE DoctorID =
         (SELECT DoctorID FROM Doctor JOIN UserId ON userid.userid = doctor.userid WHERE username = ?) AND date = ?");
        $stmt->bind_param("ss", $usernameSession, $filter);
        $stmt->execute();
        $result = $stmt->get_result();
    
        if ($result === false) {
            // Query execution failed
            echo "Error: " . $conn->error;
        }
    
        // Fetch data into an array
        $data = array();
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    
        // Return data as JSON for the JavaScript function
        header('Content-Type: application/json');
        echo json_encode($data);
    }


    if (isset($_GET['presInfoFilter'])) {
        $filter = $_GET['presInfoFilter'];
    
        // Select statement
        $sql = "SELECT prescription.Name, doctor.LastName as prescribed, prescription.reason, prescription.instructions, prescription.status FROM prescription
                JOIN doctor ON prescription.DoctorID = doctor.doctorid
                WHERE prescription.PrescriptionID = $filter";
    
        $result = $conn->query($sql);
    
        if ($result === false) {
            // Query execution failed
            echo "Error: " . $conn->error;
        }
    
        // Fetch data into an array
        $data = array();
        while ($row = $result->fetch_assoc()) {
            $data = $row;
        }
    
        // Return data as JSON for the JavaScript function
        header('Content-Type: application/json');
        echo json_encode($data);
    }

    if (isset($_GET['presInfoFilterDoc'])) {
        $filter = $_GET['presInfoFilterDoc'];
    
        // Select statement
        $sql = "SELECT patient.FirstName, patient.LastName, prescription.Name, doctor.LastName as prescribed, prescription.reason, prescription.instructions, prescription.status FROM prescription
                JOIN doctor ON prescription.DoctorID = doctor.doctorid
                JOIN patient ON prescription.PatientID = patient.PatientID
                WHERE prescription.PrescriptionID = $filter";
    
        $result = $conn->query($sql);
    
        if ($result === false) {
            // Query execution failed
            echo "Error: " . $conn->error;
        }
    
        // Fetch data into an array
        $data = array();
        while ($row = $result->fetch_assoc()) {
            $data = $row;
        }
    
        // Return data as JSON for the JavaScript function
        header('Content-Type: application/json');
        echo json_encode($data);
    }

    if (isset($_GET['patientAppointments'])) {
        $filter = $_GET['patientAppointments'];
        // To prevent SQL injection, use prepared statements
        $stmt = $conn->prepare("SELECT AppointmentID, Date, Time, Type FROM appointment  WHERE PatientID = ?");
        $stmt->bind_param("s", $filter);
        $stmt->execute();
        $result = $stmt->get_result();
    
        if ($result === false) {
            // Query execution failed
            echo "Error: " . $conn->error;
        }
    
        // Fetch data into an array
        $data = array();
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    
        // Return data as JSON for the JavaScript function
        header('Content-Type: application/json');
        echo json_encode($data);
    }


    if (isset($_GET['patientAppointmentFilter'])) {
        $filter = $_GET['patientAppointmentFilter'];
    
        // Select statement
        $sql = "SELECT appointmentID FROM appointment
                WHERE appointmentID = $filter";
    
        $result = $conn->query($sql);
    
        if ($result === false) {
            // Query execution failed
            echo "Error: " . $conn->error;
        }
    
        // Fetch data into an array
        $data = array();
        while ($row = $result->fetch_assoc()) {
            $data = $row;
        }
    
        // Return data as JSON for the JavaScript function
        header('Content-Type: application/json');
        echo json_encode($data);
    }

    if (isset($_GET['emailFilterDoctor'])) {
        $filter = $_GET['emailFilterDoctor'];

        // select statement, checking for patientid, on or past current date and ordered by date, then only get 1
        $sql = 
            "SELECT email
            FROM doctor 
            JOIN userid 
            ON doctor.UserID = userid.UserID
            WHERE doctor.doctorID = $filter";
        $result = $conn->query($sql);

        if ($result === false) {
            // Query execution failed
            echo "Error: " . $conn->error;
        }

        // Fetch data into an array
        $data = array();
        while ($row = $result->fetch_assoc()) {
            $data = $row;
        }

        // Return data as JSON for the javascript function
        header('Content-Type: application/json');
        echo json_encode($data);
    }

    // Close the database connection
   

    if (isset($_GET['billingInfoFilter'])) {
        $filter = $_GET['billingInfoFilter'];
    
        // Select statement
        $sql = "SELECT patient.FirstName, patient.LastName, billing.details, billing.insurancename, billing.insurancenumber, billing.Address, billing.creditnumber FROM billing
                JOIN patient ON billing.PatientID = patient.PatientID
                WHERE billing.patientid = $filter";
    
        $result = $conn->query($sql);
    
        if ($result === false) {
            // Query execution failed
            echo "Error: " . $conn->error;
        }
    
        // Fetch data into an array
        $data = array();
        while ($row = $result->fetch_assoc()) {
            $data = $row;
        }
    
        // Return data as JSON for the JavaScript function
        header('Content-Type: application/json');
        echo json_encode($data);
    }

    if (isset($_GET['appDoctor']) && isset($_GET['appDate'])) {
        $doctorID = $_GET['appDoctor'];
        $date = $_GET['appDate'];
        // To prevent SQL injection, use prepared statements
        $stmt = $conn->prepare("SELECT DATE_FORMAT(Time, '%H:%i') as 'Time' FROM appointment WHERE DoctorID = ? AND Date = ?");
        $stmt->bind_param("ss", $doctorID, $date);
        $stmt->execute();
        $result = $stmt->get_result();
    
        if ($result === false) {
            // Query execution failed
            echo "Error: " . $conn->error;
        }
    
        // Fetch data into an array
        $data = array();
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    
        // Return data as JSON for the JavaScript function
        header('Content-Type: application/json');
        echo json_encode($data);
    }

    $conn->close();

 ?>