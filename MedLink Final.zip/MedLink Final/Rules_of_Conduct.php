<?php

     // Session Code
     session_start();

     // Check if the user is logged in
     if (isset($_SESSION['username'])) {
       $usernameSession = $_SESSION['username'];
     }
 
     // Connection to database
     $server = 'localhost';
     $username = 'SeniorProjects';
     $password = 'Password';
     $db = 'MedLink';
 
     $conn = new mysqli($server, $username, $password, $db);
 
     if ($conn->connect_error) {
         die("Fatal Error: Database Connection");
     }
    
        

    $conn->close();
 ?>

<!DOCTYPE html>
<html>
<head>
    <title>Rules of Conduct</title>
    <link rel="stylesheet" href="Rules_of_Conduct.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
</head>
<body>
    <div class="container1">
        <img class="logo" src="img/MedLink_Logo.png" alt="logo">
        ,<h1>Rules of Conduct</h1>
    </div>
    <div class="container2">
        <p> The users of MedLink agree to adhere to the following rules and are subject to disciplenary actions deemed fit by Medlink if broken:<br><br>
        <b>1.</b> Medical staff shall hold paramount the safety, health, and &nbsp;&nbsp;&nbsp;welfare of the public.<br>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>A.</b> Medical staff are to use MedLink services to help &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;their patients, and by extension, their community.<br>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>B.</b> Medical staff will not use MedLink services to &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;negatively impact any patients in their care, 
            or any of &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;MedLink's systems.<br>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>C.</b> Medical staff will not use MedLink services to harm &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;or negatively impact any other medical staff members.<br>
            <br>

            <b>2.</b> Medical staff will only preform services in areas of their &nbsp;&nbsp;&nbsp;compotence.<br>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>A.</b> Medical staff will not update patient records for &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;patients they do not directly serve.<br>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>B.</b> Medical staff will update patient &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;info at the earliest possibility to &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ensure that records are properly &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;maintainted.<br>
            <br>

            <b>3.</b> Medical staff shall issue public statements only in an &nbsp;&nbsp;&nbsp;objective and &nbsp;&nbsp;&nbsp;truthful manner.<br>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>A.</b> Medical staff will only send messages to patients &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;when necessary.<br>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>B.</b> Medical staff will not message patients with anything &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;that does not pertain to medical information.<br>
            <br>

            <b>4.</b> Medical staff shall act for each employer or client as &nbsp;&nbsp;&nbsp;faithful agents or trsutees.<br>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>A.</b> Medical staff must disclose all known or potential &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;conflicts of interests that could influence or appear to &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;influence their judgement or the quality of their &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;service.<br>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>B.</b> Medical staff shall not accept compensation, &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;financial or otherwise, from more than one party for &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;services they preform.<br>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>C.</b> Medical staff shall not solicit or accept a contract &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;from a governmental body on which a principal or officer &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;of their organization serves as a member.<br>
            <br>

            <b>5.</b> Medical Staff shall be guided in all their relations by &nbsp;&nbsp;&nbsp;the highest standards of honestly and integrity.<br>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>A.</b> Medical staff are to acknowledge their errors and &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;shall not distort or alter facts.<br>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>B.</b> Medical staff shall not promote their own interest at &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;the expense of their patients.<br>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>C.</b> Medical staff shall treat all persons with dignity, &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;respect, fairness, and without discrimination.<br>
            <br><br><br>
            By signing up for MedLink services, all users agree to adhere to the previously mentioned rules of conduct.
              </p>
    </div>
    <div class="container3"> 
    <a href="javascript:history.back()">Go Back</a>
    </div>
</body>
</html> 