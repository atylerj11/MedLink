<?php
//PHPMailer stuff
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Include PHPMailer autoload.php file
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

// Connection to database
$server = 'localhost';
$username = 'SeniorProjects';
$password = 'Password';
$db = 'MedLink';

$conn = new mysqli($server, $username, $password, $db);

if ($conn->connect_error) {
    die("Fatal Error: Database Connection");
}

//create new mail object
$mail = new PHPMailer(true);

//try to fill and send email
try {
    $mail->isSMTP();
    //setting up gmail info
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'MedLinkTeam@gmail.com'; 
    $mail->Password = 'hxaz eqnp mmma secm '; //app password, google wont authenticate using regular password 'SeniorProjectMedLink' 
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;

    $appointmentID = $_POST["appointmentID"];
    $secretary = $_POST["secretary"];

    // Select statement
    $sql = "SELECT AppointmentID, DATE_FORMAT(Date, '%b %D') as 'DateSubject', DATE_FORMAT(Date, '%W %M %D') as 'Date', DATE_FORMAT(Time, '%H:%i') as 'Time'
    , Type, patient.FirstName, doctor.LastName, Email FROM appointment
    JOIN patient ON appointment.PatientID = patient.PatientID
    JOIN userid ON patient.UserID = userid.UserID
    JOIN doctor ON appointment.DoctorID = doctor.DoctorID
    WHERE AppointmentID = $appointmentID";

    $result = $conn->query($sql);

    $row = $result->fetch_assoc();

    $mail->setFrom('MedLinkTeam@gmail.com', "$secretary with Dr. {$row['LastName']}"); 
    $mail->addAddress($row["Email"]); // patient's email address
    $mail->Subject = "Doctor Appointment on: {$row['DateSubject']}"; // subject
    //Main message
    $mail->Body = 
"Hello {$row['FirstName']},
<br><br>You have a {$row['Type']} appointment with Dr. {$row['LastName']} on {$row['Date']} at {$row['Time']}. 
<br>If you cannot make it, be sure to cancel your appointment on <a href='https://MedLink.com'>MedLink</a>.
<br><br>See you then!";
    //message for non-HTML mail clients
    $mail->AltBody=
"Hello {$row['FirstName']},
    You have a {$row['Type']} appointment with Dr. {$row['LastName']} on {$row['Date']} at {$row['Time']}. 
    If you cannot make it, be sure to cancel your appointment on MedLink.  
See you then!";

    $mail->send();
    header("Location: success.php?success=15");
} 
//PHPMailer exception catching
catch (Exception $e) {
    header("Location: error.php?error=21");
}
?>