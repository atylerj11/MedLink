<?php
    // Connection to database
    $server = 'localhost';
    $username = 'SeniorProjects';
    $password = 'Password';
    $db = 'MedLink';

    $conn = new mysqli($server, $username, $password, $db);

    // Session Code
    session_start();

    // Check if the user is logged in
    if (isset($_SESSION['username'])) {
      $usernameSession = $_SESSION['username'];
    } else {
      // Redirect to the login page if the user is not logged in
      header("Location: login.html");
    }

    //get DoctorID from Session
    $doctorQuery = "SELECT DoctorID FROM Doctor WHERE UserID = (Select UserID FROM UserID Where username = ?)";
    $stmtDoctor = $conn->prepare($doctorQuery);

    if ($stmtDoctor) {
        $stmtDoctor->bind_param("s", $usernameSession);
        if($stmtDoctor->execute()){
            $stmtDoctor->bind_result($doctorID);
            $stmtDoctor->fetch();
            $stmtDoctor->close();
        }
    }else{
        echo "No DoctorID Found <br>";
    }

    if (isset($_POST['test'])) {
        $testName = $_POST['test'];
    }
    
    if (isset($_POST['tPatient'])) {
        $patientID = $_POST['tPatient'];
    }
    
    if (isset($_POST['tPatient']) && !empty($_FILES['pdf_file']['name'])) {
        if ($_FILES['pdf_file']['error'] != 0) {
            echo 'Something is wrong with the file.';
        } else {
            $file_name = $_FILES['pdf_file']['name'];
            $file_tmp = $_FILES['pdf_file']['tmp_name'];
        }
    }

    $NULL = null;
    $file_Data = file_get_contents($file_tmp);

    if ($file_Data) {
        $sql = "INSERT INTO Tests (TestID, PatientID, DoctorID, TestName, FileUpload, FileName) VALUES (NULL, ?, ?, ?, ?, ?)";
        $stmtTests  = $conn->prepare($sql);

        if ($stmtTests ) {
            $stmtTests ->bind_param("sssbs", $patientID, $doctorID, $testName, $file_Data, $file_name);
            $stmtTests ->send_long_data(3, $file_Data);

            if ($stmtTests ->execute()) {
                header("Location: success.php?success=7");
            } else {
                header("Location: error.php?error=11");
            }
        } else {
            echo "Error: <br>" . mysqli_error($conn);
        }
    } else {
        // Handle the case when $file_Data is empty.
        echo "File data is empty or missing.";

    }

    $stmtTests->close();

?>