<?php
//PHPMailer stuff
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Include PHPMailer autoload.php file
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

// Connection to database
$server = 'localhost';
$username = 'SeniorProjects';
$password = 'Password';
$db = 'MedLink';

$conn = new mysqli($server, $username, $password, $db);

if ($conn->connect_error) {
    die("Fatal Error: Database Connection");
}

$email = $_POST["email"];

$queryResult = mysqli_query($conn, "SELECT userid FROM userid WHERE email = '$email'");
$row = mysqli_fetch_assoc($queryResult);

//create new mail object
$mail = new PHPMailer(true);

$message = "Here is your Password Reset Link: http://localhost/MedLink%20Final/email_password_reset_form.php?userid={$row['userid']}";

//try to fill and send email
try {
    $mail->isSMTP();
    //setting up gmail info
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'MedLinkTeam@gmail.com'; 
    $mail->Password = 'hxaz eqnp mmma secm '; //app password, google wont authenticate using regular password 'SeniorProjectMedLink' 
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;

    $mail->setFrom('MedLinkTeam@gmail.com', 'MedLink Team'); //adds name of doctor as sender
    $mail->addAddress($_POST["email"]); // patient's email address
    $mail->Subject = 'Password Reset Link'; // subject
    $mail->Body = $message; //message

    $mail->send();
    header("Location: success.php?success=17");
} 
//PHPMailer exception catching
catch (Exception $e) {
    header("Location: error.php?error=25");
}
?>
