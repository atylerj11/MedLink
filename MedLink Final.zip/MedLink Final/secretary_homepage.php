<?php 

    session_start();

    // Check if the user is logged in
    if (isset($_SESSION['username'])) {
    $usernameSession = $_SESSION['username'];
    } else {
    // Redirect to the login page if the user is not logged in
    header("Location: login.html");
    }

    // Connection to database
    $server = 'localhost';
    $username = 'SeniorProjects';
    $password = 'Password';
    $db = 'MedLink';

    $conn = new mysqli($server, $username, $password, $db);

    if ($conn->connect_error) {
        die("Fatal Error: Database Connection");
    }

    
    $queryResult = mysqli_query($conn, "SELECT * FROM userid WHERE username = '$usernameSession'");
    //store querry into an array
    $row = mysqli_fetch_assoc($queryResult);

    
 ?>

<!DOCTYPE html>
<html>
<head>
    <title>Med Link Secretary Homepage</title>
    <link rel="stylesheet" href="secretary_layout.css">
    <link rel="stylesheet" href="secretary_homepage.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    
</head>
<body>
    <!-- Top Nav Bar -->
    <header>
        <a href="secretary_homepage.php"><img class="logo" src="img/MedLink_Logo.png" alt="logo"></a>
        <nav>
            <ul class="nav_buttons">
                <li><a href="secretary_appointments.php"><span class="material-icons">calendar_month</span>Appointments</a></li>
                <li><a href="secretary_create_appointments.php"><span class="material-icons">edit_note</span>Create Appointment</a></li>
                <li><a href="secretary_billing.php"><span class="material-icons">payments</span>Billing Information</a></li>
            </ul>
        </nav>
        <a href="#" class="menu-icon" onclick="toggleDropdown()"><span class="material-icons">menu</span></a>
        <div class="dropdown_menu">
            <span class="close-icon" onclick="toggleDropdown()">&times;</span>
            <li class="hidden"><a href="secretary_appointments.php"><span class="material-icons">calendar_month</span>Appointments</a></li>
            <li class="hidden"><a href="secretary_create_appointments.php"><span class="material-icons">edit_note</span>Create Appointment</a></li>
            <li class="hidden"><a href="secretary_billing.php"><span class="material-icons">payments</span>Billing Information</a></li>
            <li><a href="Contact_Us.php"><span class="material-icons">call</span>Contact us</a></li>
            <li><a href="logout.php"><span class="material-icons">logout</span>Logout</a></li>
        </div>
    </header>
    <script>
        const togglebtn = document.querySelector('.menu-icon')
        const dropdownMenu = document.querySelector(".dropdown_menu")

        function toggleDropdown() {
            dropdownMenu.classList.toggle('open');
            // Toggle the menu icon between "menu" and "close"
            const menuIcon = document.querySelector('.menu-icon .material-icons');
            menuIcon.textContent = menuIcon.textContent === 'menu' ? 'close' : 'menu';
        }
    </script>
   
    <!-- Body of Page -->
    <main>
        <!-- Left Side -->
        <div class="container1">
            <div class="con_welcome">
                <div class="welcome">Welcome back</div>
                <div class="name">
                    <?php echo $row["FirstName"] . " " . $row["LastName"]; ?>
                </div>
            </div>
            <div class="upcoming">Upcoming Appointments Today</div>
            <div class="con_appointment">
                <!-- initiation of php loop to generate appointment cards -->
                
                <?php 
                
                // SQL query to retrieve patient information
                    $sql = "SELECT appointmentID, doctor.FirstName, doctor.LastName, Date, Time, CONCAT(Date, ' ', Time) as 'Chrono' FROM patient 
                    JOIN appointment ON patient.patientid = appointment.patientID JOIN doctor ON appointment.doctorid = doctor.doctorid 
                    WHERE Date = CURDATE()
                    ORDER BY Chrono;";
                    $result = $conn->query($sql);

                    if ($result === false) {
                        // Query execution failed
                        echo "Error: " . $conn->error;
                    } else {

                        if($result->num_rows == 0){
                            ?>
                            <!-- Patient Card -->
                            <div class="card">
                                <div class="info">
                                    <div class="name">
                                        <?php echo "No appointments for today."; ?>
                                    </div>
                                </div>
                            </div>
                            <?php
                        }
                            
                        while ($row = $result->fetch_assoc()) {
                            // Display patient information for each row
                            ?>
                            <!-- Patient Card -->
                            <div class="card">
                                <div class="info">
                                    <div class="name">
                                        <?php echo "Dr. ".$row["FirstName"] . " " . $row["LastName"]; ?>
                                    </div>

                                    <div class="time">
                                        <?php echo $row["Date"] . " at " . $row["Time"]; ?>
                
                                    </div>
                                         
                                </div>
        
                                <div>
                                    <form action="cancel_appointment.php" method="post">
                                        <button input type="submit" name= "appointmentID" value="<?php echo $row["appointmentID"]?>">Cancel Appointment</button>
                                    </form>
                                </div>

                            </div>
                            <?php
                            }

                        }   
                       

                        // Close the database connection
                        $conn->close();
                ?>
                
            </div>
        </div>
        <!-- Right Side -->
        <div class="container2">
            <nav>
                <li><a href="create_patient_form.php" class="purple">Add Patient <br>to System</a></li>
                <li><a href="secretary_billing.php" class="white">Create Billing Information</a></li>
                <li><a href="secretary_billing.php" class="purple">Update Billing <br>Information</a></li>    
            </nav>
        </div>
        
    </main>

    <!-- Bottom Nav Bar -->
    <footer>
        <ul class="nav_buttons">
            <li><a href="Rules_Of_Conduct.php">Rules of Conduct</a></li>
            <li><a href="Privacy_Policy.php">Privacy Policy</a></li>
            <li><a href="FAQ.php">Need Help?</a></li>
        </ul>
    </footer>
</body>
</html> 