<?php
    // Connection to database
        $server = 'localhost';
        $username = 'SeniorProjects';
        $password = 'Password';
        $db = 'MedLink';

        $conn = new mysqli($server, $username, $password, $db);

        if ($conn->connect_error) {
            die("Fatal Error: Database Connection");
        }

        if (isset($_POST['firstname'])) {
            $firstname = $_POST['firstname'];
        }

        if (isset($_POST['lastname'])) {
            $lastname = $_POST['lastname'];
        }
    
        if (isset($_POST['gender'])) {
            $gender = $_POST['gender'];
        }
    
        if (isset($_POST['dob'])) {
            $dob = $_POST['dob'];
        }
    
        if (isset($_POST['emergencyname'])) {
            $emergencyname = $_POST['emergencyname'];
        }

        if (isset($_POST['ePhonenumber'])) {
            $ePhonenumber = $_POST['ePhonenumber'];
        }

        if (isset($_POST['allergies'])) {
            $allergies = $_POST['allergies'];
        }

        if (isset($_POST['conditions'])) {
            $conditions = $_POST['conditions'];
        }

        if (isset($_POST['existingillness'])) {
            $existingillness = $_POST['existingillness'];
        }


        $checkQuery =  $conn->prepare("SELECT FirstName, LastName FROM patient WHERE FirstName = ? AND LastName = ?");
        $checkQuery->bind_param("ss", $firstname, $lastname);
        $checkQuery->execute();
        $checkQuery = $checkQuery->get_result();
    
        if ($checkQuery->num_rows > 0) {
    
            echo "Error: " . $conn->error;
    
        } else {
        // SQL query to insert the prescription into the "prescriptions" table
            $sql = "INSERT INTO patient 
            (PatientID, UserID, FamilyID, Firstname, LastName, Gender, DateOfBirth, EmergencyName, EmergencyPhoneNumber, Allergies, Conditions, ExistingIllnesses) 
            VALUES (NULL, NULL, NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            // Prepare the SQL statement
            $stmt = $conn->prepare($sql);

            if ($stmt) {
                // Bind the parameters and execute the query
                $stmt->bind_param("sssssssss", $firstname, $lastname, $gender, $dob, $emergencyname, $ePhonenumber, $allergies, $conditions, $existingillness);
                if ($stmt->execute()) {
                    header("Location: success.php?success=13");
                } else {
                    header("Location: error.php?error=19");
                }

                // Close the statement
                $stmt->close();
            } else {
                header("Location: error.php?error=19");
            }
        }

    ?>