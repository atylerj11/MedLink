<?php

// Connection to database
$server = 'localhost';
$username = 'SeniorProjects';
$password = 'Password';
$db = 'MedLink';

$conn = new mysqli($server, $username, $password, $db);

if ($conn->connect_error) {
    die("Fatal Error: Database Connection");
}

if(isset($_POST['userid'])){
    $userid = $_POST['userid'];
}

if(isset($_POST['newpassword'])){
    $newpassword = $_POST['newpassword'];
}

if(isset($_POST['confirmpassword'])){
    $confirmpassword = $_POST['confirmpassword'];
}


if ($newpassword != $confirmpassword) {
    header("Location: error.php?error=22");
} else {

    $hash = password_hash($newpassword, PASSWORD_DEFAULT);
    $passwordQuery = $conn->prepare("UPDATE userid SET password= ? WHERE userid = ? ");
    $passwordQuery->bind_param("ss", $hash, $userid);
    
    if($passwordQuery->execute()){
        header("Location: success.php?success=16");
    }else{
        header("Location: error.php?error=24");
    }

}

?>