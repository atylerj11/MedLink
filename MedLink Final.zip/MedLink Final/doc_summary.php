<?php 
    // Session Code
    session_start();

    // Check if the user is logged in
    if (isset($_SESSION['username'])) {
      $usernameSession = $_SESSION['username'];
    } else {
      // Redirect to the login page if the user is not logged in
      header("Location: login.html");
    }

    // Connection to database
    $server = 'localhost';
    $username = 'SeniorProjects';
    $password = 'Password';
    $db = 'MedLink';

    $conn = new mysqli($server, $username, $password, $db);

    if ($conn->connect_error) {
        die("Fatal Error: Database Connection");
    }
 ?>

<!DOCTYPE html>
<html>
<head>
    <title>Doctor Appointment Summary</title>
    <link rel="stylesheet" href="DocLayout.css">
    <link rel="stylesheet" href="doc_summary.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

<script>
//search through patient cards
function searchPatients() {
    var search = document.getElementById("search").value.toLowerCase();
    var cards = document.getElementsByClassName("card");

    for (var i = 0; i < cards.length; i++) {
            var name = cards[i].getElementsByClassName("name")[0].textContent.toLowerCase();
            if (name.includes(search)) {
                cards[i].style.display = "flex";
            } else {
                cards[i].style.display = "none";
            }
    }
}

function report(patient, name, report) {
    //Checks what button was pressed
    if (report === "summary") {
        //hides other reports and shows current
        document.getElementById("formTest").style.display = "none";
        document.getElementById("formDiagnosis").style.display = "none";
        document.getElementById("formSummary").style.display = "flex";
        //populates dropdropdown
        populateDropdown(patient);
        //changes name
        document.getElementById("patientSummary").innerText = name;
        //adds patientid to value of the button
        document.getElementById("sPatient").value = patient;
    }
    else if (report === "test") {
        //hides other reports and shows current
        document.getElementById("formDiagnosis").style.display = "none";
        document.getElementById("formSummary").style.display = "none";
        document.getElementById("formTest").style.display = "flex";
        //changes name
        document.getElementById("patientTest").innerText = name;
        //adds patientid to value of the button
        document.getElementById("tPatient").value = patient;
    }
    else if (report === "diagnosis") {
        //hides other reports and shows current
        document.getElementById("formSummary").style.display = "none";
        document.getElementById("formTest").style.display = "none";
        document.getElementById("formDiagnosis").style.display = "flex";
        //changes name
        document.getElementById("patientDiagnosis").innerText = name;
        //adds patientid to value of the button
        document.getElementById("dPatient").value = patient;
    }
}

function populateDropdown(patient) {
    // Get the select element
    var dropdown = document.getElementById("appointment");

    // Clear existing options
    dropdown.innerHTML = "";

    fetch('php_functions.php?patientAppointments=' + patient)
    .then(response=>response.json())
    .then(data=> {
        let appointmentdata=data;
        console.log(appointmentdata);
        appointmentdata.forEach(function(appointment) {
            var option = document.createElement("option");
            option.text = appointment.Date + ", " + appointment.Time + " - " + appointment.Type; 
            option.value = appointment.AppointmentID; 
            dropdown.appendChild(option);
        });
    })
}

</script>
</head>
<body>
    <!-- Top Nav Bar -->
    <header>
        <a href="doc_homepage.php"><img class="logo" src="img/MedLink_Logo.png" alt="logo"></a>
        <nav>
            <ul class="nav_buttons">
                <li><a href="doc_calendar.php"><span class="material-icons">calendar_month</span>Calendar</a></li>
                <li><a href="doc_view_prescription.php"><span class="material-icons">medication</span>Medication</a></li>
                <li><a href="doc_patient.php"><span class="material-icons">man</span>Patients</a></li>
                <li><a href="doc_message.php"><span class="material-icons">mail</span>Message</a></li>
            </ul>
        </nav>
        <a href="#" class="menu-icon" onclick="toggleDropdown()"><span class="material-icons">menu</span></a>
        <div class="dropdown_menu">
            <span class="close-icon" onclick="toggleDropdown()">&times;</span>
            <li class="hidden"><a href="doc_calendar.php"><span class="material-icons">calendar_month</span>Calender</a></li>
            <li class="hidden"><a href="doc_view_prescription.php"><span class="material-icons">medication</span>Medication</a></li>
            <li class="hidden"><a href="doc_patient.php"><span class="material-icons">man</span>Patients</a></li>
            <li class="hidden"><a href="#"><span class="material-icons">mail</span>Message</a></li>
            <li><a href="Contact_Us.php"><span class="material-icons">call</span>Contact us</a></li>
            <li><a href="logout.php"><span class="material-icons">logout</span>Logout</a></li>
        </div>
    </header>
    <script>
        const togglebtn = document.querySelector('.menu-icon')
        const dropdownMenu = document.querySelector(".dropdown_menu")

        function toggleDropdown() {
            dropdownMenu.classList.toggle('open');
            // Toggle the menu icon between "menu" and "close"
            const menuIcon = document.querySelector('.menu-icon .material-icons');
            menuIcon.textContent = menuIcon.textContent === 'menu' ? 'close' : 'menu';
        }
    </script>
   <!-- Body of Page -->
    <main>
        <div class="header">Create Reports</div>
        <div class="content">
            <!-- Left Side -->
            <div class="container1">
                <div class="inputArea searchBar">
                    <input type="text" id="search" class="inputField" name="search" placeholder="" onkeyup="searchPatients()">
                    <label class="label">Search</label>
                    <span class="bottomBorder"></span>
                    <span class="bar"></span>
                </div>
                <div class="container2">
                     <!-- initiation of php loop to generate patient cards -->
                    <?php 
                        // SQL query to retrieve patient information
                        $sql = "SELECT PatientID, FirstName, LastName, FamilyID FROM patient";
                        $result = $conn->query($sql);

                        if ($result === false) {
                            // Query execution failed
                            echo "Error: " . $conn->error;
                        } else {
                            while ($row = $result->fetch_assoc()) {
                                // Display patient information for each row
                                ?>
                                <!-- Patient Card -->
                                <div class="card ">
                                    <div class="info">
                                        <div class="name">
                                            <?php echo $row["FirstName"] . " " . $row["LastName"]; ?>
                                        </div>
                                        <div class="family">
                                            <?php echo $row["FamilyID"]; ?>
                                        </div>
                                    </div>
                                    <div class="btn">
                                        <button onclick="report('<?php echo $row['PatientID']; ?>', '<?php echo $row['FirstName'] . ' ' . $row['LastName']; ?>', 'summary')">Appointment Summary</button>
                                        <button onclick="report('<?php echo $row['PatientID']; ?>', '<?php echo $row['FirstName'] . ' ' . $row['LastName']; ?>', 'test')">Test Result</button>
                                        <button onclick="report('<?php echo $row['PatientID']; ?>', '<?php echo $row['FirstName'] . ' ' . $row['LastName']; ?>', 'diagnosis')">Diagnosis</button>
                                    </div>
                                </div>
                                <?php
                            } 
                        }
                    ?>
                </div>
            </div>
            <!-- Right Side -->
            <div class="container3">

                <!-- Summary -->
                <form id="formSummary" class="report summary" action="insert_appointment_summary.php" method="POST">
                    <!-- Subject -->
                    <select name="appointment" id="appointment">
                    </select>
                    <!-- Summary -->
                    <div class="bodyArea">
                        <textarea name="message" class="bodyText" placeholder="" required></textarea>
                        <label class="bodyLabel">Write Summary Here</label> 
                    </div>
                    <!-- Summary Button -->
                    <div class="bottomInfo">
                        <div id="patientSummary"></div>
                        <button class="button" type="submit" id="sPatient" name="sPatient" value="">Send Summary</button>
                    </div>
                </form>
                
                <!-- Test -->
                <form id="formTest" class="report test" action="insert_pdf.php" method="POST" enctype="multipart/form-data">
                    <!-- Test Name -->
                    <div class="inputArea emailLine">
                        <input type="text"  class="inputField" name="test" placeholder="" required>
                        <label class="label">Test Name</label>
                        <span class="bottomBorder"></span>
                        <span class="bar"></span>
                    </div>
                    <!-- File -->
                    <input type="file" id="file" name="pdf_file" accept=".pdf"/>
                    <!-- Test Button -->
                    <div class="bottomInfo">
                        <div id="patientTest"></div>
                        <button class="button" type="submit" id="tPatient" name="tPatient" value="">Send Test Result</button>
                    </div>
                </form>

                <!-- Diagnosis -->
                <form id="formDiagnosis" class="report diagnosis" action="insert_diagnoses.php" method="POST">
                    <!-- Subject -->
                    <div class="inputArea emailLine">
                        <input type="text"  class="inputField" name="diagnosis" placeholder="" required>
                        <label class="label">Diagnosis</label>
                        <span class="bottomBorder"></span>
                        <span class="bar"></span>
                    </div>
                    <!-- Body -->
                    <div class="bodyArea">
                        <textarea name="message" class="bodyText" placeholder="" required></textarea>
                        <label class="bodyLabel">Write Explanation Here</label> 
                    </div>
                    <!-- Diagnosis Button -->
                    <div class="bottomInfo">
                        <div id="patientDiagnosis"></div>
                        <button class="button" type="submit" id="dPatient" name="dPatient" value="">Send Diagnosis</button>
                    </div>
                </form>

            </div>
        </div>
    </main>

    <!-- Bottom Nav Bar -->
    <footer>
        <ul class="nav_buttons">
            <li><a href="Rules_Of_Conduct.php">Rules of Conduct</a></li>
            <li><a href="Privacy_Policy.php">Privacy Policy</a></li>
            <li><a href="FAQ.php">Need Help?</a></li>
        </ul>
    </footer>
</body>
</html> 