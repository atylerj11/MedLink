<?php
    // Connection to database
    $server = 'localhost';
    $username = 'SeniorProjects';
    $password = 'Password';
    $db = 'MedLink';

    $conn = new mysqli($server, $username, $password, $db);


     // Session Code
     session_start();

     // Check if the user is logged in
     if (isset($_SESSION['username'])) {
       $usernameSession = $_SESSION['username'];
     } else {
       // Redirect to the login page if the user is not logged in
       header("Location: login.html");
     }
 
     //get DoctorID from Session
     $doctorQuery = "SELECT DoctorID FROM Doctor WHERE UserID = (Select UserID FROM UserID Where username = ?)";
     $stmtDoctor = $conn->prepare($doctorQuery);
 
     if ($stmtDoctor) {
         $stmtDoctor->bind_param("s", $usernameSession);
         if($stmtDoctor->execute()){
             $stmtDoctor->bind_result($doctorID);
             $stmtDoctor->fetch();
             $stmtDoctor->close();
         }
     }else{
         echo "No DoctorID Found <br>";
     }
    
    if (isset($_POST['dPatient'])) {
        $patientID = $_POST['dPatient'];
    }
    
    if (isset($_POST['diagnosis'])) {
        $diagnosis = $_POST['diagnosis'];
    }

    if (isset($_POST['message'])) {
        $description = $_POST['message'];
    }

    $insertSummaryQuery = "INSERT INTO Diagnoses (DiagnosisID, DoctorID, PatientID, Diagnosis, Description, Date) VALUES (NULL, ?, ?, ?, ?, CURDATE())";

    $stmt = $conn->prepare($insertSummaryQuery);

    if ($stmt) {
        // Bind the parameters and execute the query
        $stmt->bind_param("ssss", $doctorID, $patientID, $diagnosis, $description);
        if ($stmt->execute()) {
            header("Location: success.php?success=8");
        } else {
            header("Location: error.php?error=12");
        }
        // Close the statement
        $stmt->close();
    } else {
        header("Location: error.php");
    }
?>  