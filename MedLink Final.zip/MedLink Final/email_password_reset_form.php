<?php

if (isset($_GET['userid'])) {
    $userid = $_GET['userid'];
}
else {
    header("Location: password_reset_form.html");
}

?>

<!DOCTYPE html>
<html>  

    <head>  
        <meta charset="utf-8">
        <title> MedLink Reset Password </title>
        <link rel="stylesheet" href="login.css">


    </head>



    <body>

        <div class="center_container";>
            <h1>Forgot Password</h1>
            <form method="post" action="password_reset.php" onsubmit="return validate(this)">
                <div class="textField">
                    <input type="text" id="newpassword" name="newpassword" required>
                    <span></span>
                    <label>New Password</label>   
                </div>
                <div class="textField">
                    <input type="text" id="confirmpassword" name="confirmpassword" required>
                    <span></span>
                    <label>Confirm Password</label>   
                </div>
                <button class ="btn btn2" type="submit" name="userid" value="<?php echo $userid; ?>" >Reset Password</button>
                <div class ="signup">Not a member? <a href="Register.html">Sign up</a></div>
            </form>
        </div>
        

    </body>


</html>