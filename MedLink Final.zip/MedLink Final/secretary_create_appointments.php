<?php 
    // Session Code
    session_start();

    // Check if the user is logged in
    if (isset($_SESSION['username'])) {
      $usernameSession = $_SESSION['username'];
    } else {
      // Redirect to the login page if the user is not logged in
      header("Location: login.html");
    }

    // Connection to database
    $server = 'localhost';
    $username = 'SeniorProjects';
    $password = 'Password';
    $db = 'MedLink';

    $conn = new mysqli($server, $username, $password, $db);

    if ($conn->connect_error) {
        die("Fatal Error: Database Connection");
    }
 ?>
<!DOCTYPE html>
<html>


<head>
    <title>Med Link Create Appointments</title>
    <link rel="stylesheet" href="secretary_layout.css">
    <link rel="stylesheet" href="secretary_create_appntmnt.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

    <script>
    
    //search through patient cards

    function searchPatients() {
        var search = document.getElementById("search").value.toLowerCase();
        var cards = document.getElementsByClassName("patient_name"); // Update the class name

        for (var i = 0; i < cards.length; i++) {
            var name = cards[i].getElementsByClassName("name")[0].textContent.toLowerCase();
            if (name.includes(search)) {
                cards[i].style.display = "flex";
            } else {
                cards[i].style.display = "none";
            }
        }
    }
    

    
    function showOrHide(patient) {
    const centerContainer = document.getElementById("centerContainer");
    const containerCards = document.getElementById("containerCards");
    document.getElementById("textfield").value = patient;
    if (window.getComputedStyle(centerContainer).display === "none") {
        centerContainer.style.display = "flex";
        containerCards.style.display = "none"; 
        
    } else {
        centerContainer.style.display = "none";
        containerCards.style.display = "flex"; 
    }
    }

    // Search Functionality
    //waits for page to load
    document.addEventListener("DOMContentLoaded", function () {
    //gets each field input
    const doctorSelect = document.getElementById('doctorSelect');
    const dateSelect = document.getElementById('dateSelect');

    //checks if drop down options change
    doctorSelect.addEventListener('change', function () {
        populateDropdown();
    });

    dateSelect.addEventListener('change', function () {
        populateDropdown();
    });

    function populateDropdown() {
        //gets selected doctor and date
        const selectedDoctor = doctorSelect.options[doctorSelect.selectedIndex].value;
        const selectedDate = dateSelect.value;

        //gets time dropdown element
        var timeSelect = document.getElementById("timeSelect");
        
        if (selectedDoctor === "" || selectedDate === "") {
            timeSelect.innerHTML = '';
            var option = document.createElement("option");
            option.text = "Pick Date & Dr";
            option.disabled = true;
            //adds option to dropdown
            timeSelect.add(option);
            return;
        }

        // Start at 8 AM (0800)
        var startTime = new Date();
        startTime.setHours(8, 0, 0, 0);

        // Set the end time to 5 PM (1700)
        var endTime = new Date();
        endTime.setHours(17, 0, 0, 0); 

    fetch('php_functions.php?appDoctor=' + selectedDoctor + '&appDate=' + selectedDate)
        .then(response => response.json())
        .then(data => {
            let timeData = data;
            console.log(timeData);
            timeSelect.innerHTML = '';

            // Loop to generate options while start time is <= end time
            while (startTime <= endTime) {
                var option = document.createElement("option");
                var timeString = startTime.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });

                if (timeData.some(item => item.Time === timeString)) {
                    option.style.backgroundColor = 'darkgrey';
                    option.disabled = true;
                } else {
                    option.value = timeString;
                    option.text = timeString;
                }

                timeSelect.add(option);
                startTime.setMinutes(startTime.getMinutes() + 30);
            }
        })
        // Handle the errors
        .catch(error => {
            console.error('Error:', error);
        });
    }   
});
   

    </script>

</head>



<body>
   <!-- Top Nav Bar -->
   <header>
        <a href="secretary_homepage.php"><img class="logo" src="img/MedLink_Logo.png" alt="logo"></a>
        <nav>
            <ul class="nav_buttons">
                <li><a href="secretary_appointments.php"><span class="material-icons">calendar_month</span>Appointments</a></li>
                <li><a href="secretary_create_appointments.php"><span class="material-icons">edit_note</span>Create Appointment</a></li>
                <li><a href="secretary_billing.php"><span class="material-icons">payments</span>Billing Information</a></li>
            </ul>
        </nav>
        <a href="#" class="menu-icon" onclick="toggleDropdown()"><span class="material-icons">menu</span></a>
        <div class="dropdown_menu">
            <span class="close-icon" onclick="toggleDropdown()">&times;</span>
            <li><a href="logout.php"><span class="material-icons">logout</span>Logout</a></li>
            <li><a href="secretary_appointments.php"><span class="material-icons">calendar_month</span>Appointments</a></li>
            <li><a href="secretary_create_appointments.php"><span class="material-icons">edit_note</span>Create Appointment</a></li>
            <li><a href="secretary_billing.php"><span class="material-icons">payments</span>Billing Information</a></li>
            <li><a href="Contact_Us.php"><span class="material-icons">call</span>Contact us</a></li>
        </div>
    </header>
    <script>
        const togglebtn = document.querySelector('.menu-icon')
        const dropdownMenu = document.querySelector(".dropdown_menu")

        function toggleDropdown() {
            dropdownMenu.classList.toggle('open');
            // Toggle the menu icon between "menu" and "close"
            const menuIcon = document.querySelector('.menu-icon .material-icons');
            menuIcon.textContent = menuIcon.textContent === 'menu' ? 'close' : 'menu';
        }
    </script>

   <!-- Body of Page -->
    <main>
        
        <div class="header"><h1>Create appointments</h1></div>

        
        <div class="container_search" id="containerCards">

            <div class="inputArea">
                <input type="text" id="search" name="search" placeholder="" onkeyup="searchPatients()">
                <label class="label">Search</label>
                <span class="bottomBorder"></span>
                <span class="bar"></span>
            </div>


            <div class="container_cards">
                <?php 
                        // SQL query to retrieve patient information
                        $sql = "SELECT PatientID, FirstName, LastName FROM patient";
                        $result = $conn->query($sql);

                        if ($result === false) {
                            // Query execution failed
                            header("Location: error.php?23");
                        } else {
                            while ($row = $result->fetch_assoc()) {
                                // Display patient information for each row
                                ?>
                                <!-- Patient Card -->
                                <div class="patient_name ">
                                    
                                        <div class="name">
                                            <?php echo $row["FirstName"] . " " . $row["LastName"]; ?>
                                        </div>
                                        
                                    
                                    <div class="create_button">
                                        <!-- makes a button and sends php variable of the cards patient to the JS function -->
                                        <button type="button" onclick="showOrHide('<?php echo $row['PatientID']; ?>')">Create Appointments</button>

                                    </div>
                                </div>
                                <?php
                            }
                            
                        }
                ?>               
                
            </div>

           

        </div>
        <div class="center_container" id="centerContainer">
            <form method="post" action="create_appointment.php" onsubmit="return validate(this)">

                <!-- Patient -->
                <?php 
                    //query get patient data
                    $queryResult = mysqli_query($conn, "SELECT * FROM patient WHERE PatientID = (SELECT PatientID FROM patient join userid on userid.UserID = patient.UserID WHERE username = '$usernameSession')");
                    //store querry into an array
                    $row = mysqli_fetch_assoc($queryResult);
                ?>
                <div class="inputArea emailLine">
                    <input type="text"  id ="textfield" class="inputField" name="PatientID" placeholder="" value="<?php echo $row['PatientID']; ?>" readonly required>
                    <label class="label">PatientID</label>
                    <span class="bottomBorder"></span>
                    <span class="bar"></span>
                </div>

                <!-- Doctor -->
                <label class="label2" for="doctorSelect">Doctor</label>
                <select name="DoctorID" class="doctor" id="doctorSelect" required>
                    <option disabled selected></option>
                    <!-- initiation of php loop to generate doctors -->
                    <?php 
                        // SQL query to retrieve doctor list
                        $sql = "SELECT * FROM doctor";
                        $result = $conn->query($sql);

                        if ($result === false) {
                            // Query execution failed
                            echo "Error: " . $conn->error;
                        } 
                        else {
                            while ($row = $result->fetch_assoc()) {
                                // Display doctor options, value is doctorid and the last name is displayed
                                ?>
                                    <option value="<?php echo $row['doctorid'] ?>"><?php echo 'Dr. ' . $row['LastName'] ?></option>
                                <?php
                            }
                        }
                    // Close the database connection
                     $conn->close(); 
                    ?>
                </select>

                <!-- Date -->
                <div class="inputArea emailLine">
                    <label class="label2" for="dateSelect" required>Date</label>
                    <input class="date" id="dateSelect" type="date" name="Date"/>
                </div>

                <!-- Time -->
                <label class="label2" for="timeSelect">Time</label>
                <select name="Time" id="timeSelect" required>
                    <option disabled>Pick Date & Dr</option>
                </select>

                <!-- Type -->
                <div class="inputArea emailLine">
                    <input type="text"  class="inputField" name="Type" placeholder="" required>
                    <label class="label">Type</label>
                    <span class="bottomBorder"></span>
                    <span class="bar"></span>
                </div>
                
                <input class ="btn" type="submit" value="Create Appointment">
                
            </form>
            <button class ="btn btn2" type="button" onclick="showOrHide()">Back</button>
        </div>
        
    </main>








    <!-- Bottom Nav Bar -->
    <footer>
        <ul class="nav_buttons">
            <li><a href="Rules_Of_Conduct.php">Rules of Conduct</a></li>
            <li><a href="Privacy_Policy.php">Privacy Policy</a></li>
            <li><a href="FAQ.php">Need Help?</a></li>
        </ul>
    </footer>

</body>
</html> 