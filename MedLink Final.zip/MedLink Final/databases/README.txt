How to Implement Database into AMPPS -> phpMyAdmin.

Open AMPPS, in the Menu click HOME.

This will take you to a page with a sidebar menu and a list of features for AMPPS.

Look for DATABASE TOOLS and click PHPMYADMIN.

This will ask you to login. The information for the login: 

Username: Root (Should already be filled in)
Password: mysql (ALL LOWERCASE)

On the left sidebar, there is a button that says NEW. 
Please click this and it will allow you to create a database.
Type the name "medlink" with no quotation marks for the database name and click create.

The database "medlink" will now appear in the side bar. Click on it.
At the top menu of this new page, click Import. 
Inside this folder there should be a SQL File called "setupDB"

Where it says Choose File, please locate the file "setupDB" and insert it here.
Scroll all the way down and click import. All tables should be included now. 