<?php
    // Connection to database
        $server = 'localhost';
        $username = 'SeniorProjects';
        $password = 'Password';
        $db = 'MedLink';

        $conn = new mysqli($server, $username, $password, $db);

        if ($conn->connect_error) {
            die("Fatal Error: Database Connection");
        }

        if (isset($_POST['PatientID'])) {
            $patientid = $_POST['PatientID'];
        }

        if (isset($_POST['details'])) {
            $details = $_POST['details'];
        }
    
        if (isset($_POST['insurancename'])) {
            $insurancename = $_POST['insurancename'];
        }
    
        if (isset($_POST['insurancenumber'])) {
            $insurancenumber = $_POST['insurancenumber'];
        }
    
        if (isset($_POST['address'])) {
            $address = $_POST['address'];
        }

        if (isset($_POST['creditnumber'])) {
            $creditnumber = $_POST['creditnumber'];
        }

        $checkQuery =  $conn->prepare("SELECT PatientID FROM billing WHERE PatientID = ?");
        $checkQuery->bind_param("s", $patientid);
        $checkQuery->execute();
        $checkQuery = $checkQuery->get_result();
    
        if ($checkQuery->num_rows > 0) {
    
            echo "Error: " . $conn->error;
    
        } else {
        // SQL query to insert the prescription into the "prescriptions" table
        $sql = "INSERT INTO billing 
        (BillingID, PatientID, Details, InsuranceName, InsuranceNumber, Address, CreditNumber) 
        VALUES (NULL, ?, ?, ?, ?, ?, ?)";

            // Prepare the SQL statement
            $stmt = $conn->prepare($sql);

            if ($stmt) {
                // Bind the parameters and execute the query
                $stmt->bind_param("isssss", $patientid, $details, $insurancename, $insurancenumber, $address, $creditnumber);
                if ($stmt->execute()) {
                    header("Location: success.php?success=14");
                } else {
                    header("Location: error.php?error=20");
                }

                // Close the statement
                $stmt->close();
            } else {
                header("Location: error.php?error=20");
            }
        }

    ?>