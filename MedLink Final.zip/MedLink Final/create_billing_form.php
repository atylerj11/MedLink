<?php 
    // Session Code
    session_start();

    // Check if the user is logged in
    if (isset($_SESSION['username'])) {
      $usernameSession = $_SESSION['username'];
    } else {
      // Redirect to the login page if the user is not logged in
      header("Location: login.html");
    }

    // Connection to database
    $server = 'localhost';
    $username = 'SeniorProjects';
    $password = 'Password';
    $db = 'MedLink';

    $conn = new mysqli($server, $username, $password, $db);

    if ($conn->connect_error) {
        die("Fatal Error: Database Connection");
    }

    if (!(isset($_POST['create']))) {
        echo "Error with recipient";
    }
    else {
        $patient = $_POST['create'];
    }

    $sql = "SELECT patient.patientid, patient.FirstName FROM patient 
    WHERE PatientID = $patient";
    $result = $conn->query($sql);

    if ($result === false) {
        die("Query error: " . $conn->error); // Print the MySQL error message for debugging.
    }

    if ($result->num_rows == 0) {
        die("No results found for PatientID: $patient"); // Handle the case when no results are found.
    }
    
    $row = $result->fetch_assoc();

    $FirstName = htmlspecialchars($row['FirstName']);


 ?>
<!DOCTYPE html>
<html>
<head>
    <title>Secretary Create Billing</title>
    <link rel="stylesheet" href="secretary_layout.css">
    <link rel="stylesheet" href="secretary_update_billing.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
</head>
<body>
   <!-- Top Nav Bar -->
   <header>
        <a href="secretary_homepage.php"><img class="logo" src="img/MedLink_Logo.png" alt="logo"></a>
        <nav>
            <ul class="nav_buttons">
                <li><a href="secretary_appointments.php"><span class="material-icons">calendar_month</span>Appointments</a></li>
                <li><a href="secretary_create_appointments.php"><span class="material-icons">edit_note</span>Create Appointment</a></li>
                <li><a href="secretary_billing.php"><span class="material-icons">payments</span>Billing Information</a></li>
            </ul>
        </nav>
        <a href="#" class="menu-icon" onclick="toggleDropdown()"><span class="material-icons">menu</span></a>
        <div class="dropdown_menu">
            <span class="close-icon" onclick="toggleDropdown()">&times;</span>
            <li><a href="logout.php"><span class="material-icons">logout</span>Logout</a></li>
            <li><a href="secretary_appointments.php"><span class="material-icons">calendar_month</span>Appointments</a></li>
            <li><a href="secretary_create_appointments.php"><span class="material-icons">edit_note</span>Create Appointment</a></li>
            <li><a href="secretary_billing.php"><span class="material-icons">payments</span>Billing Information</a></li>
            <li><a href="Contact_Us.php"><span class="material-icons">call</span>Contact us</a></li>
        </div>
    </header>
    <script>
        const togglebtn = document.querySelector('.menu-icon')
        const dropdownMenu = document.querySelector(".dropdown_menu")

        function toggleDropdown() {
            dropdownMenu.classList.toggle('open');
            // Toggle the menu icon between "menu" and "close"
            const menuIcon = document.querySelector('.menu-icon .material-icons');
            menuIcon.textContent = menuIcon.textContent === 'menu' ? 'close' : 'menu';
        }
    </script>

   <!-- Body of Page -->
   <main>
        <!-- Name -->
        <div class="header">Creating Billing Information <br> for <?php echo $patient . "{$row['FirstName']}";?></div>
        <div class="content">
            <!-- Update Form -->
            <form class="card" action="create_billing_info.php" method="post">
                <!-- Details -->
                <div class="inputArea">
                    <input type="text" class="inputField" name="details" placeholder="" >
                    <label class="label">Details</label>
                    <span class="bottomBorder"></span>
                    <span class="bar"></span>
                </div>
                <!-- Insurance Name -->
                <div class="inputArea">
                    <input type="text" class="inputField" name="insurancename" placeholder="" >
                    <label class="label">Insurance Name</label>
                    <span class="bottomBorder"></span>
                    <span class="bar"></span>
                </div>
                <!-- Insurance Number-->
                <div class="inputArea">
                    <input type="text" class="inputField" name="insurancenumber" placeholder="" >
                    <label class="label">Insurance Number</label>
                    <span class="bottomBorder"></span>
                    <span class="bar"></span>
                </div>
                <!-- Address-->
                <div class="inputArea">
                    <input type="text" class="inputField" name="address" placeholder="" >
                    <label class="label">Address</label>
                    <span class="bottomBorder"></span>
                    <span class="bar"></span>
                </div>
                <!-- Credit Card Number -->
                <div class="inputArea">
                    <input type="text" class="inputField" name="creditnumber" placeholder="" >
                    <label class="label">Credit Number</label>
                    <span class="bottomBorder"></span>
                    <span class="bar"></span>
                </div>
                <!-- Submit Button -->
                <button type="submit" name="PatientID" value="<?php echo $patient;?>">Create Billing Information</button>
            </form>
        </div>
    </main>
    <!-- Bottom Nav Bar -->
    <footer>
        <ul class="nav_buttons">
            <li><a href="Rules_Of_Conduct.php">Rules of Conduct</a></li>
            <li><a href="Privacy_Policy.php">Privacy Policy</a></li>
            <li><a href="FAQ.php">Need Help?</a></li>
        </ul>
    </footer>
</body>
</html>
