<?php 

    session_start();

    // Check if the user is logged in
    if (isset($_SESSION['username'])) {
      $usernameSession = $_SESSION['username'];
    } else {
      // Redirect to the login page if the user is not logged in
      header("Location: login.html");
    }

    // Connection to database
    $server = 'localhost';
    $username = 'SeniorProjects';
    $password = 'Password';
    $db = 'MedLink';

    $conn = new mysqli($server, $username, $password, $db);

    if ($conn->connect_error) {
        die("Fatal Error: Database Connection");
    }

    //query changed to using username
    $queryResult = mysqli_query($conn, "SELECT * FROM userid WHERE username = '$usernameSession'");
    //store querry into an array
    $row = mysqli_fetch_assoc($queryResult);
/*UserID = (SELECT UserID FROM UserID WHERE username = '$usernameSession')*/

    // SQL query to retrieve patient information
    
 ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head> 
    <meta charset="utf-8">
    <title>Med Link Doctor Homepage</title>
    <link rel="stylesheet" href="DocLayout.css">
    <link rel="stylesheet" href="Doc_Calendar.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
</head>
<body>
    <!-- Top Nav Bar -->
    <header>
        <a href="doc_homepage.php"><img class="logo" src="img/MedLink_Logo.png" alt="logo"></a>
        <nav>
            <ul class="nav_buttons">
                <li><a href="doc_calendar.php"><span class="material-icons">calendar_month</span>Calendar</a></li>
                <li><a href="doc_view_prescription.php"><span class="material-icons">medication</span>Medication</a></li>
                <li><a href="doc_patient.php"><span class="material-icons">man</span>Patients</a></li>
                <li><a href="doc_message.php"><span class="material-icons">mail</span>Message</a></li>
            </ul>
        </nav>
        <a href="#" class="menu-icon" onclick="toggleDropdown()"><span class="material-icons">menu</span></a>
        <div class="dropdown_menu">
            <span class="close-icon" onclick="toggleDropdown()">&times;</span>
            <li class="hidden"><a href="doc_calendar.php"><span class="material-icons">calendar_month</span>Calender</a></li>
            <li class="hidden"><a href="doc_view_prescription.php"><span class="material-icons">medication</span>Medication</a></li>
            <li class="hidden"><a href="doc_patient.php"><span class="material-icons">man</span>Patients</a></li>
            <li class="hidden"><a href="#"><span class="material-icons">mail</span>Message</a></li>
            <li><a href="#"><span class="material-icons">call</span>Contact us</a></li>
            <li><a href="logout.php"><span class="material-icons">logout</span>Logout</a></li>
        </div>
    </header>
    <script>
        const togglebtn = document.querySelector('.menu-icon')
        const dropdownMenu = document.querySelector(".dropdown_menu")

        function toggleDropdown() {
            dropdownMenu.classList.toggle('open');
            // Toggle the menu icon between "menu" and "close"
            const menuIcon = document.querySelector('.menu-icon .material-icons');
            menuIcon.textContent = menuIcon.textContent === 'menu' ? 'close' : 'menu';
        }

            function getDate() {
                var date = document.getElementById("my-date-picker").value;
                var username = document.getElementById("ButtonID").value;
                fetch('php_functions.php?appointment='+ date + '&usernameSession=' + username)
                .then(response=>response.json())
                .then(data=> {
                    let appointmentdata=data;
                    console.log(appointmentdata);
                    displayAppointments(appointmentdata);
                })
            }
 

    function displayAppointments(appointments) {
    var resultContainer = document.getElementById("results-container");

    // Clear previous results
    resultContainer.innerHTML = '';

    // Check if there are appointments
    if (appointments.length === 0) {
        var appointmentDiv = document.createElement("div");
        appointmentDiv.className = "card";

        var noAppointmentsMessage = document.createElement("p");
        noAppointmentsMessage.textContent = "No appointments for this day.";
        appointmentDiv.appendChild(noAppointmentsMessage);
        resultContainer.appendChild(appointmentDiv);
    } else {
        // Loop through the appointments and create HTML elements for each
        appointments.forEach(function (appointment) {
            var appointmentDiv = document.createElement("div");
            appointmentDiv.className = "card";

            var type = document.createElement("p");
            type.textContent = "Type: " + appointment.Type;

            var firstName = document.createElement("p");
            firstName.textContent = "First Name: " + appointment.FirstName;

            var lastName = document.createElement("p");
            lastName.textContent = "Last Name: " + appointment.LastName;

            var appointmentDate = document.createElement("p");
            appointmentDate.textContent = "Date: " + appointment.Date;

            var time = document.createElement("p");
            time.textContent = "Time: " + appointment.Time;

            appointmentDiv.appendChild(type);
            appointmentDiv.appendChild(firstName);
            appointmentDiv.appendChild(lastName);
            appointmentDiv.appendChild(appointmentDate);
            appointmentDiv.appendChild(time);

            resultContainer.appendChild(appointmentDiv);
        });
    }
}
    </script>
    </header>

   <!-- Body of Page -->
    <main>
         <fieldset class="CustomCalendar">
            <legend class="Cal_Header"><b>Upcoming Appointments</b></legend>
            <label for="my-date-picker" class="Cal_Header">Date:</label>
                <input id="my-date-picker"
                       type="date"
                       min="2019-12-31" 
                       list="my-special-dates"
                       max="2024-02-29" 
                       name="" 
                       value=""/>

                       <!--Gets value when buttong is clicked-->
                       <button class="ButtonClass" onclick="getDate()"
                               id="ButtonID"
                               value="<?php  echo $usernameSession?>">Click here to Update Appointments</button>

                       
         </fieldset> 
        
         <div class="container" id="results-container">
            

         </div>
                    
        </main>

    <!-- Bottom Nav Bar -->
    <footer>
        <ul class="nav_buttons">
            <li><a href="Rules_Of_Conduct.php">Rules of Conduct</a></li>
            <li><a href="Privacy_Policy.php">Privacy Policy</a></li>
            <li><a href="FAQ.php">Need Help?</a></li>
        </ul>
    </footer>
</body>
</html> 