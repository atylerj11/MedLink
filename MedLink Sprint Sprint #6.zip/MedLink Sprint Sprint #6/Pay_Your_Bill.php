<?php 
    // Connection to database
    $server = 'localhost';
    $username = 'SeniorProjects';
    $password = 'Password';
    $db = 'MedLink';

    $conn = new mysqli($server, $username, $password, $db);

    if ($conn->connect_error) {
        die("Fatal Error: Database Connection");
    }

    if (isset($_GET['userId'])) {
        $userId = $_GET['userId'];
    }
    else {
        $userId = 1;
    }
    
    $sql = "SELECT * FROM userid WHERE UserID = $userId";
    $queryResult = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($queryResult);

    // $query = $conn->prepare("SELECT * FROM userid WHERE UserID = ?");
    // $query->bind_param("i", $userId);
    // $query->execute();
    // $queryResult = $query->get_result();
    // $row = mysqli_fetch_assoc($queryResult);
 ?>

<!DOCTYPE html>
<html>
<head>
    <title>Med Link Pay your Bill</title>
    <link rel="stylesheet" href="layout.css">
    <link rel="stylesheet" href="Pay_Your_Bill.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
</head>
<body>
    <!-- Top Nav Bar -->
    <header>
        <a href="patient_homepage.php"><img class="logo" src="img/MedLink_Logo.png" alt="logo"></a>
        <nav>
            <ul class="nav_buttons">
                <li><a href="#"><span class="material-icons">calendar_month</span>Calender</a></li>
                <li><a href="patient_medication.php"><span class="material-icons">medication</span>Medication</a></li>
                <li><a href="#"><span class="material-icons">science</span>Results</a></li>
                <li><a href="#"><span class="material-icons">mail</span>Message</a></li>
            </ul>
        </nav>
        <a href="#"><span class="material-icons">menu</span></a>
    </header>
   
    <!-- Body of Page -->
    <main>
        <!-- -->
        <div class="Title">
            <p><b>Appointment Payment</b></p>
        </div>

        <div class="container">


        <div class="Paragraph">
            <p>Clicking the button below will redirect your web browser to open a new window and prompt you to log into the Appointment Payment Center. Your MedLink session will remain active in your origina browser window. Please be sure to log out of both systems and close all browser windows when you are done</p>
        </div>

        <div class="Button">
        
            <script>
                const windowFeatures = "left=100,top=100,width=320,height=320"; 
                //window.open("Rules_of_Conduct.php", "chromeWindow");

            </script>
            <a href="javascript:history.back()" target="chromeWindow">Enter Appointment Payment Center</a>
        </div>

        <div class="Paragraph2">
            <p>Please be aware that MedLink is not responsible for any transactional issues that occur on the webpage. If you believe that there is an incorrect bill on your page, please contact our office at (xxx)-xxx-xxxx.</p>
        </div>
</div>
<style>
a:link{
    color:black;
}

a:visited{
    color:#6a0080;
}

</style>
    </main>

    <!-- Bottom Nav Bar -->
    <footer>
        <ul class="nav_buttons">
            <li><a href="Rules_of_Conduct.php">Rules of Conduct</a></li>
            <li><a href="Privacy_Policy.php">Privacy Policy</a></li>
            <li><a href="FAQ.php">Need Help?</a></li>
        </ul>
    </footer>
</body>
</html> 