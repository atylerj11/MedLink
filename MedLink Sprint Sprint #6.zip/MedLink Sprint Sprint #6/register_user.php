<?php
    // connection to the database
    $server = 'localhost';
    $username = 'SeniorProjects';
    $password = 'Password';
    $db = 'MedLink';
    $conn = new mysqli($server, $username, $password, $db);

    if ($conn->connect_error) {
        die("Fatal Error: Database Connection");
    }

    if (isset($_POST['username'])) {
        $username = $_POST['username'];
    }

    if (isset($_POST['email'])) {
        $email = $_POST['email'];
    }

    if (isset($_POST['FirstName'])) {
        $firstName = $_POST['FirstName'];
    }

    if (isset($_POST['LastName'])) {
        $lastName = $_POST['LastName'];
    }

    if (isset($_POST['password'])) {
        $password = $_POST['password'];
    }

    if (isset($_POST['confirmpassword'])) {
        $confirm = $_POST['confirmpassword'];
    }

    $hash = password_hash($password, PASSWORD_DEFAULT);

    if ($password != $confirm) {
        header("Location: error.php?22");
    } else {
        // Check if the user's first and last name match a record in the doctor table
        $doctorQuery = $conn->prepare("SELECT DoctorID FROM doctor WHERE FirstName = ? AND LastName = ?");
        $doctorQuery->bind_param("ss", $firstName, $lastName);
        $doctorQuery->execute();
        $doctorResult = $doctorQuery->get_result();

        // Check if the user is a secretary
        $secretaryQuery = $conn->prepare("SELECT SecretaryID FROM secretary WHERE FirstName = ? AND LastName = ?");
        $secretaryQuery->bind_param("ss", $firstName, $lastName);
        $secretaryQuery->execute();
        $secretaryResult = $secretaryQuery->get_result();

        // Check if the user is a patient
        $patientQuery = $conn->prepare("SELECT PatientID FROM patient WHERE FirstName = ? AND LastName = ?");
        $patientQuery->bind_param("ss", $firstName, $lastName);
        $patientQuery->execute();
        $patientResult = $patientQuery->get_result();

        //User is a doctor
        if ($doctorResult->num_rows > 0) {

            //INSERT INTO USERID TABLE
            $insertQuery = $conn->prepare("INSERT INTO MedLink.UserID (UserID, Username, Password, Email, FirstName, LastName) VALUES (NULL, ?, ?, ?, ?, ?)");
            $insertQuery->bind_param("sssss", $username, $hash, $email, $firstName, $lastName);

            if ($insertQuery->execute()) {

                //UPDATE DOCTOR TABLE
                $updateQuery = $conn->prepare("UPDATE MedLink.Doctor SET UserID = (SELECT UserID FROM MedLink.UserID WHERE FirstName = ? AND LastName = ?) WHERE FirstName = ? AND LastName = ?");
                $updateQuery->bind_param("ssss", $firstName, $lastName, $firstName, $lastName);
                if ($updateQuery->execute()) {
                    header("Location: success.php?success=1");
                } else {
                    header("Location: error.php?error=4");
                }

            } else {

                header("Location: error.php?error=4");
            }

        // User is a secretary
        } elseif ($secretaryResult->num_rows > 0) {

            //INSERT INTO USERID TABLE
            $insertQuery = $conn->prepare("INSERT INTO MedLink.UserID (UserID, Username, Password, Email, FirstName, LastName) VALUES (NULL, ?, ?, ?, ?, ?)");
            $insertQuery->bind_param("sssss", $username, $hash, $email, $firstName, $lastName);

            if ($insertQuery->execute()) {

                //UPDATE SECRETARY TABLE
                $updateQuery = $conn->prepare("UPDATE MedLink.Secretary SET UserID = (SELECT UserID FROM MedLink.UserID WHERE FirstName = ? AND LastName = ?) WHERE FirstName = ? AND LastName = ?");
                $updateQuery->bind_param("ssss", $firstName, $lastName, $firstName, $lastName);
                if ($updateQuery->execute()) {
                    header("Location: success.php?success=1");
                } else {
                    header("Location: error.php?error=4");
                }
            } else {
                header("Location: error.php?error=4");
            }

        //User is a patient
        } elseif ($patientResult->num_rows > 0) {

            //INSERT INTO USERID TABLE
            $insertQuery = $conn->prepare("INSERT INTO MedLink.UserID (UserID, Username, Password, Email, FirstName, LastName) VALUES (NULL, ?, ?, ?, ?, ?)");
            $insertQuery->bind_param("sssss", $username, $hash, $email, $firstName, $lastName);

            if ($insertQuery->execute()) {

                //UPDATE USERID IN PATIENT TABLE
                $updateQuery = $conn->prepare("UPDATE MedLink.Patient SET UserID = (SELECT UserID FROM MedLink.UserID WHERE FirstName = ? AND LastName = ?) WHERE FirstName = ? AND LastName = ?");
                $updateQuery->bind_param("ssss", $firstName, $lastName, $firstName, $lastName);
                if ($updateQuery->execute()) {
                    header("Location: success.php?success=1");
                } else {
                    header("Location: error.php?error=4");
                }
            } else {
                header("Location: error.php?error=4");
            }
        } else {
            
            // User is none of the above.
            header("Location: error.php?error=5");
        }

        $conn->close();
    }
?>
