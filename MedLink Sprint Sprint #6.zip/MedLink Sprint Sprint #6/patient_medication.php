<?php 
    // Session Code
    session_start();

    // Check if the user is logged in
    if (isset($_SESSION['username'])) {
      $usernameSession = $_SESSION['username'];
    } else {
      // Redirect to the login page if the user is not logged in
      header("Location: login.html");
    }

    // Connection to database
    $server = 'localhost';
    $username = 'SeniorProjects';
    $password = 'Password';
    $db = 'MedLink';

    $conn = new mysqli($server, $username, $password, $db);

    if ($conn->connect_error) {
        die("Fatal Error: Database Connection");
    }
 ?>

<!DOCTYPE html>
<html>
<head>
    <title>Med Link Patient Homepage</title>
    <link rel="stylesheet" href="layout.css">
    <link rel="stylesheet" href="patient_medication.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

    <script>
        //search for patient info to fill in more info card
        function prescription_info(prescription) {
            // Checks if the info card is hidden or visible, if it is, sets it to be visible
            var infoCard = document.getElementById("infoCard");
            if (window.getComputedStyle(document.getElementById("infoCard")).display === "none") {
                infoCard.style.display = "flex";
            }

            //sends the patientid to php script to get patient info
            fetch('php_functions.php?presInfoFilter=' + prescription)
                .then(response => response.json())
                .then(data => {
                    // Store the data in an associative array
                    let prescriptionData = data;
                    console.log(prescriptionData); //outputs to console for debug
                    //each line fills in relavent HTML area with information stored in the array from the PHP script
                    document.getElementById("prescriptionID").value = prescription;
                    document.getElementById("drugname").textContent = prescriptionData.Name;
                    document.getElementById("prescribed").textContent = prescriptionData.prescribed;
                    document.getElementById("reason").textContent = prescriptionData.reason;
                    document.getElementById("instruction").textContent = prescriptionData.instructions;
                    document.getElementById("status").textContent = prescriptionData.status;
                })

        }

        //search through patient cards
        function searchMedication() {
            var search = document.getElementById("search").value.toLowerCase();
            var cards = document.getElementsByClassName("card");

            for (var i = 0; i < cards.length; i++) {
                var name = cards[i].getElementsByClassName("name")[0].textContent.toLowerCase();
                if (name.includes(search)) {
                    cards[i].style.display = "flex";
                } else {
                        cards[i].style.display = "none";
                }
            }
        }
    </script>
</head>
<body>
<header>
        <a href="patient_homepage.php"><img class="logo" src="img/MedLink_Logo.png" alt="logo"></a>
        <nav>
            <ul class="nav_buttons">
                <li><a href="patient_medication.php"><span class="material-icons">medication</span>Medication</a></li>
                <li><a href="patient_appt_summary.php"><span class="material-icons">science</span>Results</a></li>
                <li><a href="patient_message.php"><span class="material-icons">mail</span>Message</a></li>
            </ul>
        </nav>
        <a href="#" class="menu-icon" onclick="toggleDropdown()"><span class="material-icons">menu</span></a>
        <div class="dropdown_menu">
            <span class="close-icon" onclick="toggleDropdown()">&times;</span>
            <li class="hidden"><a href="patient_medication.php"><span class="material-icons">medication</span>Medication</a></li>
            <li class="hidden"><a href="patient_appt_summary.php"><span class="material-icons">science</span>Results</a></li>
            <li class="hidden"><a href="patient_message.php"><span class="material-icons">mail</span>Message</a></li>
            <li><a href="#"><span class="material-icons">call</span>Contact us</a></li>
            <li><a href="Pay_Your_Bill.php"><span class="material-icons">payments</span>Pay Your Bill</a></li>
            <li><a href="logout.php"><span class="material-icons">logout</span>Logout</a></li>
        </div>
</header>
    <script>
        const togglebtn = document.querySelector('.menu-icon')
        const dropdownMenu = document.querySelector(".dropdown_menu")

        function toggleDropdown() {
            dropdownMenu.classList.toggle('open');
            // Toggle the menu icon between "menu" and "close"
            const menuIcon = document.querySelector('.menu-icon .material-icons');
            menuIcon.textContent = menuIcon.textContent === 'menu' ? 'close' : 'menu';
        }
    </script>

   <!-- Body of Page -->
    <main>
        <div class="header">Medication List</div>
        <div class="content">
            <!-- Left Side -->
            <div class="container1">
                <div class="inputArea">
                    <input type="text" id="search" name="search" placeholder="" onkeyup="searchMedication()">
                    <label class="label">Search</label>
                    <span class="bottomBorder"></span>
                    <span class="bar"></span>
                </div>
                <div class="container2">
                     <!-- initiation of php loop to generate patient cards -->
                    <?php 
                        // SQL query to retrieve patient information
                        $sql = "SELECT prescriptionID, prescription.PatientID, prescription.DoctorID, doctor.LastName, Name, Reason, Instructions FROM prescription JOIN patient on patient.patientid = prescription.patientID JOIN doctor on doctor.doctorid = prescription.doctorid WHERE prescription.patientid = (SELECT patientID FROM patient JOIN UserId ON userid.userid = patient.userid WHERE username = '$usernameSession')";
                        $result = $conn->query($sql);

                        if ($result === false) {
                            // Query execution failed
                            echo "Error: " . $conn->error;
                        } else {
                            while ($row = $result->fetch_assoc()) {
                                // Display patient information for each row
                                ?>
                                <!-- Patient Card -->
                                <div class="card ">
                                    <div class="info">
                                        <div class="name">
                                            <?php echo $row["Name"]?>
                                        </div>
                                        <div class="doctor">
                                            <?php echo "Prescribed by Dr. " . $row["LastName"]; ?>
                                        </div>
                                    </div>
                                    <div class="btn">
                                        <button onclick="prescription_info('<?php echo $row['prescriptionID']; ?>')">Click for More Info</button>
                                    </div>
                                </div>
                                <?php
                            } 
                        }
                    ?>
                </div>
            </div>
            <!-- Right Side -->
            <div class="container3">
                <div id="infoCard" class="medication">
                    <!-- Medication  Info, filled in from JavaScript function-->
                    <div class="drug">
                        <b>Drug Name: </b><span id="drugname"></span>
                    </div>
                    <div class="prescribed">
                        <b>Prescribed By:</b> Dr. <span id="prescribed"></span>
                    </div>
                    <div class="status">
                        <b>Status: </b><span id="status"></span>
                    </div>
                    <div class="reason">
                        <b>Reason: </b><span id="reason"></span> 
                    </div>
                    <div class="instruction">
                        <b>How to take: </b><span id="instruction"></span>
                    </div>
                    <form action="request_refill.php" method="post">
                        <button id="prescriptionID" class="button btn" input type="submit" name= "prescriptionID" value="prescriptionID">Request Refill</button>
                    </form>
            </div>
        </div>
    </main>

<!-- Bottom Nav Bar -->
<footer>
        <ul class="nav_buttons">
            <li><a href="Rules_Of_Conduct.php">Rules of Conduct</a></li>
            <li><a href="Privacy_Policy.php">Privacy Policy</a></li>
            <li><a href="FAQ.php">Need Help?</a></li>
        </ul>
    </footer>
</body>
</html> 