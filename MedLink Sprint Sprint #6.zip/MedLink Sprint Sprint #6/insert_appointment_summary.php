<?php
    // Connection to database
    $server = 'localhost';
    $username = 'SeniorProjects';
    $password = 'Password';
    $db = 'MedLink';

    $conn = new mysqli($server, $username, $password, $db);

    // Session Code
    session_start();

    // Check if the user is logged in
    if (isset($_SESSION['username'])) {
      $usernameSession = $_SESSION['username'];
    } else {
      // Redirect to the login page if the user is not logged in
      header("Location: login.html");
    }

    //get DoctorID from Session
    $doctorQuery = "SELECT DoctorID FROM Doctor WHERE UserID = (Select UserID FROM UserID Where username = ?;)";
    $stmt = $conn->prepare($doctorQuery);

    if ($stmt) {
        $stmt->bind_param("s", $usernameSession);
        if($stmt->execute()){
            $stmt->bind_result($doctorID);
            $stmt->fetch();
            echo $doctorID . ". <br>";
        }
    }else{
        echo "No DoctorID Found <br>";
    }

    if (isset($_POST['appointment'])) {
        $appointmentID = $_POST['appointment'];
        echo "AppointmentID " . $appointmentID . ". <br>";
    }
    
    if (isset($_POST['sPatient'])) {
        $patientID = $_POST['sPatient'];
        echo "PatientID " . $patientID . ". <br>";
    }
    
    if (isset($_POST['message'])) {
        $message = $_POST['message'];
        echo "Message: " . $message . ". <br>";
    }

    $insertSummaryQuery = "UPDATE Appointment SET AppointmentSummary = ? WHERE AppointmentID = ? AND PatientID = ?";

    $stmt = $conn->prepare($insertSummaryQuery);

    if ($stmt) {
        // Bind the parameters and execute the query
        $stmt->bind_param("sss", $message, $appointmentID, $patientID);
        if ($stmt->execute()) {
            header("Location: success.php?success=6");
        } else {
            header("Location: error.php?error=10");
        }
        // Close the statement
        $stmt->close();
    } else {
        header("Location: error.php");
    }
?>  