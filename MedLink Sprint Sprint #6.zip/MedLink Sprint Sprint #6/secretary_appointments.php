<?php 
    // Session Code
    session_start();

    // Check if the user is logged in
    if (isset($_SESSION['username'])) {
      $usernameSession = $_SESSION['username'];
    } else {
      // Redirect to the login page if the user is not logged in
      header("Location: login.html");
    }

    // Connection to database
    $server = 'localhost';
    $username = 'SeniorProjects';
    $password = 'Password';
    $db = 'MedLink';

    $conn = new mysqli($server, $username, $password, $db);

    if ($conn->connect_error) {
        die("Fatal Error: Database Connection");
    }

    $queryName = mysqli_query($conn, "SELECT CONCAT(FirstName, ' ', LastName) as 'Name' FROM userid WHERE username = '$usernameSession'");
    //store querry into an array
    $name = mysqli_fetch_assoc($queryName);
 ?>

<!DOCTYPE html>
<html>
<head>
    <title>Med Link Appointments</title>
    <link rel="stylesheet" href="secretary_layout.css">
    <link rel="stylesheet" href="secretary_appointments.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

<script>
// Search Functionality
//waits for page to load
document.addEventListener("DOMContentLoaded", function () {
    //gets each search input
    const patientSelect = document.getElementById("search");
    const doctorSelect = document.getElementById('doctorSelect');
    const dateSelect = document.getElementById('dateSelect');

    //runs the search function when input orchange is detected
    patientSelect.addEventListener('input', function () {
        performSearch();
    });

    doctorSelect.addEventListener('change', function () {
        performSearch();
    });

    dateSelect.addEventListener('change', function () {
        performSearch();
    });

    function performSearch() {
    const patientSearch = patientSelect.value.toLowerCase();
    const selectedDoctor = doctorSelect.options[doctorSelect.selectedIndex].text;
    const selectedDate = dateSelect.value;

    var cards = document.getElementsByClassName("card");

    for (var i = 0; i < cards.length; i++) {
        var pName = cards[i].getElementsByClassName("pName")[0].textContent.toLowerCase();
        var dName = cards[i].getElementsByClassName("dName")[0].textContent;
        var date = cards[i].getElementsByClassName("date")[0].textContent.trim(); // Trim date cause now it works (╯°□°)╯︵ ┻━┻

        if (pName.includes(patientSearch) &&
            (selectedDoctor === "" || dName.includes(selectedDoctor)) &&
            (selectedDate === "" || date === selectedDate)) {
            cards[i].style.display = "flex";
        } else {
            cards[i].style.display = "none";
        }
    }
}
});

</script>
</head>
<body>
    <!-- Top Nav Bar -->
    <header>
        <a href="secretary_homepage.php"><img class="logo" src="img/MedLink_Logo.png" alt="logo"></a>
        <nav>
            <ul class="nav_buttons">
                <li><a href="secretary_appointments.php"><span class="material-icons">calendar_month</span>Appointments</a></li>
                <li><a href="secretary_create_appointments.php"><span class="material-icons">edit_note</span>Create Appointment</a></li>
                <li><a href="secretary_billing.php"><span class="material-icons">payments</span>Billing Information</a></li>
            </ul>
        </nav>
        <a href="#" class="menu-icon" onclick="toggleDropdown()"><span class="material-icons">menu</span></a>
        <div class="dropdown_menu">
            <span class="close-icon" onclick="toggleDropdown()">&times;</span>
            <li class="hidden"><a href="secretary_appointments.php"><span class="material-icons">calendar_month</span>Appointments</a></li>
            <li class="hidden"><a href="secretary_create_appointments.php"><span class="material-icons">edit_note</span>Create Appointment</a></li>
            <li class="hidden"><a href="secretary_billing.php"><span class="material-icons">payments</span>Billing Information</a></li>
            <li><a href="#"><span class="material-icons">call</span>Contact us</a></li>
            <li><a href="logout.php"><span class="material-icons">logout</span>Logout</a></li>
        </div>
    </header>
    <script>
        const togglebtn = document.querySelector('.menu-icon')
        const dropdownMenu = document.querySelector(".dropdown_menu")

        function toggleDropdown() {
            dropdownMenu.classList.toggle('open');
            // Toggle the menu icon between "menu" and "close"
            const menuIcon = document.querySelector('.menu-icon .material-icons');
            menuIcon.textContent = menuIcon.textContent === 'menu' ? 'close' : 'menu';
        }
    </script>
   <!-- Body of Page -->
    <main>
        <div class="header">View and Cancel Appointments</div>
        <div class="content">
            <!-- Field Searching -->
            <div class="container1">
                <div class="searchField">
                    <!-- Date Search-->
                    <div>
                        <label class="label2" for="dateSelect">Date</label>
                        <input class="dateSelect" id="dateSelect" type="date" name="Date"/>
                    </div>

                    <!-- Doctor Search Dropdown-->
                    <div>
                        <label class="label2" for="doctorSelect">Doctor</label>
                        <select name="DoctorID" class="doctor" id="doctorSelect">
                            <!-- default, no doctor -->
                            <option></option>
                            <!-- initiation of php loop to generate doctors -->
                            <?php 
                                // SQL query to retrieve doctor list
                                $sql = "SELECT * FROM doctor";
                                $result = $conn->query($sql);

                                if ($result === false) {
                                    // Query execution failed
                                    echo "Error: " . $conn->error;
                                } 
                                else {
                                    while ($row = $result->fetch_assoc()) {
                                        // Display doctor options, value is doctorid and the last name is displayed
                                        ?>
                                            <option><?php echo 'Dr. ' . $row['LastName'] ?></option>
                                        <?php
                                    }
                                }
                            ?>
                        </select>
                    </div>

                    <!-- Patient Searchbar -->
                    <div class="inputArea searchBar">
                        <input type="text" id="search" class="inputField" name="search" placeholder="">
                        <label class="label">Patient Search</label>
                        <span class="bottomBorder"></span>
                        <span class="bar"></span>
                    </div>
                </div>
                <!-- Appointment Container -->
                <div class="container2">
                     <!-- initiation of php loop to generate appointment cards -->
                    <?php 
                        // SQL query to retrieve appointment information
                        $sql = "SELECT AppointmentID, CONCAT(patient.FirstName, ' ', patient.LastName) as 'pName',  appointment.PatientID, 
                        doctor.LastName as 'dName', appointment.DoctorID, Date, DATE_FORMAT(Time, '%H:%i') as 'Time', Type,
                        CONCAT(Date, ' ', Time) as 'Chrono'
                        FROM appointment
                        join patient on appointment.PatientID = patient.PatientID
                        join doctor on appointment.DoctorID = doctor.DoctorID
                        WHERE appointment.date >= CURDATE()
                        ORDER BY Chrono";
                        $result = $conn->query($sql);           

                        if ($result === false) {
                            // Query execution failed
                            echo "Error: " . $conn->error;
                        } else {
                            while ($row = $result->fetch_assoc()) {
                                // Display appointment information for each row
                                ?>
                                <!-- Appointment Card -->
                                <div class="card ">
                                    <!-- All Info -->
                                    <div class="info">
                                        <!-- Appointment Info -->
                                        <div class="appInfo">
                                            <!-- Date -->
                                            <div class="obj">
                                                <span>Date: </span>
                                                <div class="date">
                                                    <?php echo $row["Date"]; ?>
                                                </div>
                                            </div>
                                            <!-- Time -->
                                            <div class="obj">                    
                                                <span>Time: </span>
                                                <div class="time">
                                                    <?php echo $row["Time"]; ?>
                                                </div>
                                            </div>
                                            <!-- Type -->
                                            <div class="type obj">
                                                <span>Type:</span>
                                                <?php echo $row["Type"]; ?>
                                            </div>
                                        </div>
                                        <!-- People -->
                                        <div class="peopleInfo">
                                            <!-- Patient -->
                                            <div class="obj">
                                                <span>Patient:</span>
                                                <div class="pName">
                                                    <?php echo $row["pName"]; ?>
                                                </div>
                                            </div>
                                            <!-- Doctor -->
                                            <div class="obj">
                                                <span>Doctor:</span>
                                                <div class="dName">
                                                    <?php echo "Dr. " . $row["dName"]; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Notification Button -->
                                    <form action="send_notification.php" method="post" class="btn2">
                                        <input type="hidden" name="secretary" value="<?php echo $name["Name"]?>">
                                        <button input type="submit" name= "appointmentID" value="<?php echo $row["AppointmentID"]?>">Send<br>Notification</button>
                                    </form>
                                    <!-- Cancel Button -->
                                    <form action="cancel_appointment.php" method="post" class="btn">
                                        <button input type="submit" name= "appointmentID" value="<?php echo $row["AppointmentID"]?>">Cancel<br>Appointment</button>
                                    </form>
                                </div>
                                <?php
                            } 
                        }
                        // Close the database connection
                        $conn->close(); 
                    ?>
                </div>
            </div>
        </div>
    </main>

    <!-- Bottom Nav Bar -->
    <footer>
        <ul class="nav_buttons">
            <li><a href="Rules_Of_Conduct.php">Rules of Conduct</a></li>
            <li><a href="Privacy_Policy.php">Privacy Policy</a></li>
            <li><a href="FAQ.php">Need Help?</a></li>
        </ul>
    </footer>
</body>
</html> 