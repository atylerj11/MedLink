<?php

     // Session Code
     session_start();

     // Check if the user is logged in
     if (isset($_SESSION['username'])) {
       $usernameSession = $_SESSION['username'];
     }
 
     // Connection to database
     $server = 'localhost';
     $username = 'SeniorProjects';
     $password = 'Password';
     $db = 'MedLink';
 
     $conn = new mysqli($server, $username, $password, $db);
 
     if ($conn->connect_error) {
         die("Fatal Error: Database Connection");
     }

    //gets what error is sent to the page
    if (isset($_GET['error'])) {
        $error = $_GET['error'];
    }
    else {
        $error = 0;
    }

    //compares gotten error, to errors page can display
    switch ($error) {
    case 1:
        $msg = "It seems that you are not a member. Please go back to register.";
        $link = "login.html";
        break;
    case 2:
        $msg = "Invalid username/password combination. Please try again.";
        $link = "login.html";
        break;
    case 3:
        $msg = "Username and password are required. Please try again.";
        $link = "login.html";
        break;
    case 4:
        $msg = "There seems to be an error in your information. Please try a different username or email.";
        $link = "register.html";
        break;
    case 5:
        $msg = "It seems that you are not in the system. Please reach out to us for technical issues.";
        $link = "register.html";
        break;
    case 6:
        $msg = "There was an error with inserting this information. Please try again.";
        $link = "doc_create_prescription.php";
        break;
    case 7:
        $msg = "There was an error with inserting this information. Please try again.";
        $link = "doc_patient.php";
        break;
    case 8:
        $msg = "There was an error with requesting for a refill. Please retry or message your doctor.";
        $link = "javascript:history.back()";
        break;
    case 9:
        $msg = "There was an error with cancelling the appointment. Please try again.";
        $link = "javascript:history.back()"; 
        break;
    case 10:
        $msg = "There was an error with inserting the appointment summary.";
        $link = "doc_summary.php";   
        break; 
    case 11:
        $msg = "There was an error with uploading the file.";
        $link = "doc_summary.php";    
        break;
    case 12:
        $msg = "There was an error with creating this diagnosis. Please try again";
        $link = "doc_summary.php";    
        break;
    case 13:
        $msg = "This time and date was already booked. Please try again.";
        $link = "javascript:history.back()";    
        break;
    case 14:
        $msg = "There was an issue with creating the appointment.";
        $link = "javascript:history.back()";    
        break;
    case 15:
        $msg = "There was an error with requesting for a refill. Please retry or message your database administrator.";
        $link = "doc_view_prescription.php";
        break;
    case 16:
        $msg = "There was an error with updating this information. Please make sure there is billing information set for this patient.";
        $link = "secretary_billing.php";
        break;
    case 17:
        $msg = "There was an error with updating this information. Please make sure everything is filled out in this form.";
        $link = "secretary_billing.php";
        break;
    case 18:
        $msg = "This patient already exists in the system. Please try again.";
        $link = "javascript:history.back()";
        break;
    case 19:
        $msg = "There seems to be an error in the information provided. Please try again.";
        $link = "create_patient_form.php";
        break;
    case 20: 
        $msg = "There seems to be an error in the information provided. Please try again.";
        $link = "secretary_billing.php";
        break;
    case 21: 
        $msg = "There seems to be an error in sending the notification. Please try again.";
        $link = "secretary_appointments.php";
        break;
    case 22:
        $msg = "Passwords do not match, please go back to try again.";
        $link = "javascript:history.back()";
        break;
    case 23:
        $msg = "Patient cannot be found, please go back to try again.";
        $link = "javascript:history.back()";
        break;
    case 24:
        $msg = "There was an error with updating your password. Please go back to try again.";
        $link = "javascript:history.back()";
        break;
    case 25:
        $msg = "There was an error with sending the email, please make sure that is the email associated with your account.";
        $link = "javascript:history.back()";
        break;
    default:
        $msg = "There seems to be an error that we may not have accounted for. Please go back and try again.";
        $link = "javascript:history.back()";
    }

    $conn->close();
 ?>

<!DOCTYPE html>
<html>
<head>
    <title>Error Page</title>
    <link rel="stylesheet" href="error.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
</head>
<body>
    <div class="container1">
        <img class="logo" src="img/MedLink_Logo.png" alt="logo">
        <img class="error" src="img/error.png" alt="error">
    </div>
    <div class="container2">
        <h1><?php echo $msg;?></h1>
        <a href="<?php echo $link; ?>">Go Back</a>
    </div>
</body>
</html> 