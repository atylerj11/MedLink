<?php 
    // Session Code
    session_start();

    // Check if the user is logged in
    if (isset($_SESSION['username'])) {
      $usernameSession = $_SESSION['username'];
    } else {
      // Redirect to the login page if the user is not logged in
      header("Location: login.html");
    }

    // Connection to database
    $server = 'localhost';
    $username = 'SeniorProjects';
    $password = 'Password';
    $db = 'MedLink';

    $conn = new mysqli($server, $username, $password, $db);

    if ($conn->connect_error) {
        die("Fatal Error: Database Connection");
    }

 ?>
<!DOCTYPE html>
<html>
<head>
    <title>Secretary Create Patient</title>
    <link rel="stylesheet" href="secretary_layout.css">
    <link rel="stylesheet" href="secretary_update_billing.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
</head>
<body>
   <!-- Top Nav Bar -->
   <header>
        <a href="secretary_homepage.php"><img class="logo" src="img/MedLink_Logo.png" alt="logo"></a>
        <nav>
            <ul class="nav_buttons">
                <li><a href="secretary_appointments.php"><span class="material-icons">calendar_month</span>Appointments</a></li>
                <li><a href="secretary_create_appointments.php"><span class="material-icons">edit_note</span>Create Appointment</a></li>
                <li><a href="secretary_billing.php"><span class="material-icons">payments</span>Billing Information</a></li>
            </ul>
        </nav>
        <a href="#" class="menu-icon" onclick="toggleDropdown()"><span class="material-icons">menu</span></a>
        <div class="dropdown_menu">
            <span class="close-icon" onclick="toggleDropdown()">&times;</span>
            <li><a href="logout.php"><span class="material-icons">logout</span>Logout</a></li>
            <li><a href="secretary_appointments.php"><span class="material-icons">calendar_month</span>Appointments</a></li>
            <li><a href="secretary_create_appointments.php"><span class="material-icons">edit_note</span>Create Appointment</a></li>
            <li><a href="secretary_billing.php"><span class="material-icons">payments</span>Billing Information</a></li>
            <li><a href="#"><span class="material-icons">call</span>Contact us</a></li>
        </div>
    </header>
    <script>
        const togglebtn = document.querySelector('.menu-icon')
        const dropdownMenu = document.querySelector(".dropdown_menu")

        function toggleDropdown() {
            dropdownMenu.classList.toggle('open');
            // Toggle the menu icon between "menu" and "close"
            const menuIcon = document.querySelector('.menu-icon .material-icons');
            menuIcon.textContent = menuIcon.textContent === 'menu' ? 'close' : 'menu';
        }
    </script>

   <!-- Body of Page -->
   <main>
        <!-- Name -->
        <div class="header">Creating Patient</div>
        <div class="content">
            <!-- Update Form -->
            <form class="card" action="create_patient.php" method="post">
                <!-- Patient First Name -->
                <div class="inputArea">
                    <input type="text" class="inputField" name="firstname" placeholder="" >
                    <label class="label">First Name</label>
                    <span class="bottomBorder"></span>
                    <span class="bar"></span>
                </div>
                <!-- Patient Last Name -->
                <div class="inputArea">
                    <input type="text" class="inputField" name="lastname" placeholder="" >
                    <label class="label">Last Name</label>
                    <span class="bottomBorder"></span>
                    <span class="bar"></span>
                </div>
                <!-- Gender -->
                <div class="inputArea">
                    <input type="text" class="inputField" name="gender" placeholder="" >
                    <label class="label">Gender</label>
                    <span class="bottomBorder"></span>
                    <span class="bar"></span>
                </div>
                <!-- Date of Birth -->
                <div class="inputArea">
                    <input type="text" class="inputField" name="dob" placeholder="" >
                    <label class="label">Date of Birth (YYYY-MM-DD)</label>
                    <span class="bottomBorder"></span>
                    <span class="bar"></span>
                </div>
                <!-- Emergency Contact -->
                <div class="inputArea">
                    <input type="text" class="inputField" name="emergencyname" placeholder="" >
                    <label class="label">Emergency Contact</label>
                    <span class="bottomBorder"></span>
                    <span class="bar"></span>
                </div>
                <!-- Emergency Contact #-->
                <div class="inputArea">
                    <input type="text" class="inputField" name="ePhonenumber" placeholder="" >
                    <label class="label">Emergency Contact #</label>
                    <span class="bottomBorder"></span>
                    <span class="bar"></span>
                </div>
                <!-- Allergies-->
                <div class="inputArea">
                    <input type="text" class="inputField" name="allergies" placeholder="" >
                    <label class="label">Allergies</label>
                    <span class="bottomBorder"></span>
                    <span class="bar"></span>
                </div>
                <!-- Conditions -->
                <div class="inputArea">
                    <input type="text" class="inputField" name="conditions" placeholder="" >
                    <label class="label">Conditions</label>
                    <span class="bottomBorder"></span>
                    <span class="bar"></span>
                </div>
                <!-- Existing Illnesses -->
                <div class="inputArea">
                    <input type="text" class="inputField" name="existingillness" placeholder="" >
                    <label class="label">Existing Illnesses</label>
                    <span class="bottomBorder"></span>
                    <span class="bar"></span>
                </div>
                <!-- Submit BUtton -->
                <button type="submit" name="button" value="submit">Create Patient</button>
            </form>
        </div>
    </main>

    <!-- Bottom Nav Bar -->
    <footer>
        <ul class="nav_buttons">
            <li><a href="Rules_Of_Conduct.php">Rules of Conduct</a></li>
            <li><a href="Privacy_Policy.php">Privacy Policy</a></li>
            <li><a href="FAQ.php">Need Help?</a></li>
        </ul>
    </footer>
</body>
</html>
