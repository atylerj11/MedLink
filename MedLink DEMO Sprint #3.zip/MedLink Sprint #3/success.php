<?php

     // Session Code
     session_start();

     // Check if the user is logged in
     if (isset($_SESSION['username'])) {
       $usernameSession = $_SESSION['username'];
     }
 
     // Connection to database
     $server = 'localhost';
     $username = 'SeniorProjects';
     $password = 'Password';
     $db = 'MedLink';
 
     $conn = new mysqli($server, $username, $password, $db);
 
     if ($conn->connect_error) {
         die("Fatal Error: Database Connection");
     }

    //gets what error is sent to the page
    if (isset($_GET['success'])) {
        $success = $_GET['success'];
    }
    else {
        $error = 0;
    }

    //compares gotten error, to errors page can display
    switch ($success) {
    case 1:
        $msg = "Registered successfully! Please go back to log in.";
        $link = "login.html";
        break;
    case 2:
        $msg = "Information successfully added! Please go back to continue.";
        $link = "doc_create_prescription.php";
        break;
    case 3:
        $msg = "Information successfully added! Please go back to continue.";
        $link = "doc_patient.php";
        break;
    default:
        $msg = "There seems to be an error that we may not have accounted for. Please return to login and try again.";
        $link = "login.html";
    }

    $conn->close();
 ?>

<!DOCTYPE html>
<html>
<head>
    <title>Error Page</title>
    <link rel="stylesheet" href="error.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
</head>
<body>
    <div class="container1">
        <img class="logo" src="img/MedLink_Logo.png" alt="logo">
        <img class="error" src="img/check.png" alt="error">
    </div>
    <div class="container2">
        <h1><?php echo $msg;?></h1>
        <a href="<?php echo $link; ?>">Go Back</a>
    </div>
</body>
</html> 