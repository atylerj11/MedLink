<?php

// Connection to database
$server = 'localhost';
$username = 'SeniorProjects';
$password = 'Password';
$db = 'MedLink';

$conn = new mysqli($server, $username, $password, $db);

if ($conn->connect_error) {
    die("Fatal Error: Database Connection");
}

// Check if username and password are posted
if (isset($_POST['username']) && isset($_POST['password'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Prepare and execute the query to check the user's credentials
    $query = $conn->prepare("SELECT UserID, UserName, Password, FirstName, LastName FROM UserID WHERE UserName = ?");
    $query->bind_param("s", $username);
    $query->execute();

    $resultuser = $query->get_result();

    if (!$resultuser) {
        die("Fatal Error: " . $conn->error);
    }

    if ($resultuser->num_rows > 0) {
        $row = $resultuser->fetch_assoc();

        if (password_verify($password, $row['Password'])) {
            // User is authenticated
            $userId = $row['UserID'];
            $firstName = $row['FirstName'];
            $lastName = $row['LastName'];

            // Check if the user's first and last name match a record in the doctor table
            $doctorQuery = $conn->prepare("SELECT DoctorID FROM doctor WHERE FirstName = ? AND LastName = ?");
            $doctorQuery->bind_param("ss", $firstName, $lastName);
            $doctorQuery->execute();
            $doctorResult = $doctorQuery->get_result();

            // Check if the user is a secretary
            $secretaryQuery = $conn->prepare("SELECT SecretaryID FROM secretary WHERE FirstName = ? AND LastName = ?");
            $secretaryQuery->bind_param("ss", $firstName, $lastName);
            $secretaryQuery->execute();
            $secretaryResult = $secretaryQuery->get_result();

            // Check if the user is a patient
            $patientQuery = $conn->prepare("SELECT PatientID FROM patient WHERE FirstName = ? AND LastName = ?");
            $patientQuery->bind_param("ss", $firstName, $lastName);
            $patientQuery->execute();
            $patientResult = $patientQuery->get_result();

            if ($doctorResult->num_rows > 0) {

                // User is a doctor, display doctor's webpage
                session_start();
                $_SESSION['username'] = $row['UserName']; //should be username
                header("Location: doc_homepage.php");
                exit;

            } elseif ($secretaryResult->num_rows > 0) {

                // User is a secretary, display secretary's webpage
                session_start();
                $_SESSION['username'] = $row['UserName']; //should be username
                echo "Hi {$row['UserName']}, you are a secretary. Display secretary's webpage here.";
                exit; 

            } elseif ($patientResult->num_rows > 0) {

                // User is a patient, display patient's webpage
                session_start();
                $_SESSION['username'] = $row['UserName']; //should be username
                header("Location: patient_homepage.php");
                exit;

            } else {
                // User is none of the above roles
                header("Location: error.php?error=1");
            }
        } else {
            header("Location: error.php?error=2");
        }
    } else {
        header("Location: error.php?error=1");
    }
} else {
    header("Location: error.php?error=3");
}