-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Oct 12, 2023 at 02:34 AM
-- Server version: 8.0.31
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `medlink`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `AppointmentID` int NOT NULL,
  `PatientID` int NOT NULL,
  `DoctorID` int NOT NULL,
  `Date` date NOT NULL,
  `Time` time DEFAULT NULL,
  `Type` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`AppointmentID`, `PatientID`, `DoctorID`, `Date`, `Time`, `Type`) VALUES
(1, 1, 1, '2023-10-10', '10:30:00', 'Checkup'),
(2, 2, 1, '2023-10-12', '11:00:00', 'Follow-up'),
(3, 3, 1, '2023-10-15', '11:30:00', 'Consultation'),
(4, 4, 1, '2023-10-18', '12:00:00', 'Checkup'),
(5, 5, 1, '2023-10-20', '12:30:00', 'Follow-up'),
(6, 6, 2, '2023-10-22', '13:30:00', 'Consultation'),
(7, 7, 2, '2023-10-25', '14:00:00', 'Checkup'),
(8, 8, 2, '2023-10-28', '10:00:00', 'Follow-up'),
(9, 9, 2, '2023-10-31', '11:00:00', 'Consultation'),
(10, 10, 2, '2023-11-02', '12:00:00', 'Checkup'),
(11, 11, 3, '2023-11-05', '12:30:00', 'Follow-up'),
(12, 12, 3, '2023-11-08', '13:30:00', 'Consultation'),
(13, 13, 3, '2023-11-11', '12:30:00', 'Checkup'),
(14, 14, 3, '2023-11-14', '14:30:00', 'Follow-up'),
(15, 15, 3, '2023-11-17', '14:00:00', 'Consultation'),
(16, 16, 4, '2023-11-20', '15:00:00', 'Checkup'),
(17, 17, 4, '2023-11-23', '12:00:00', 'Follow-up'),
(18, 18, 4, '2023-11-26', '11:00:00', 'Consultation'),
(19, 19, 4, '2023-11-29', '11:30:00', 'Checkup'),
(20, 20, 4, '2023-12-02', '12:30:00', 'Follow-up'),
(21, 21, 5, '2023-12-05', '11:00:00', 'Consultation'),
(22, 22, 5, '2023-12-08', '11:30:00', 'Checkup'),
(23, 23, 5, '2023-12-11', '15:00:00', 'Follow-up'),
(24, 24, 5, '2023-12-14', '15:30:00', 'Consultation'),
(25, 25, 5, '2023-12-17', '14:00:00', 'Checkup');

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `doctorid` int NOT NULL,
  `UserID` int DEFAULT NULL,
  `FirstName` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `LastName` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`doctorid`, `UserID`, `FirstName`, `LastName`) VALUES
(1, 1, 'Eason', 'Chang'),
(2, NULL, 'Manpreet', 'Bhinder'),
(3, 2, 'Michael', 'Colella'),
(4, NULL, 'Donovan', 'Santiago'),
(5, NULL, 'Nafees', 'Ishraq');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `PatientID` int NOT NULL,
  `UserID` int DEFAULT NULL,
  `FamilyID` int DEFAULT NULL,
  `FirstName` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `LastName` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Gender` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `DateOfBirth` date DEFAULT NULL,
  `EmergencyName` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `EmergencyPhoneNumber` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Allergies` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Conditions` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `ExistingIllnesses` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `BloodPressure` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SugarLevels` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`PatientID`, `UserID`, `FamilyID`, `FirstName`, `LastName`, `Gender`, `DateOfBirth`, `EmergencyName`, `EmergencyPhoneNumber`, `Allergies`, `Conditions`, `ExistingIllnesses`, `BloodPressure`, `SugarLevels`) VALUES
(1, 3, NULL, 'Alyssa', 'Jimenez', 'Female', '2002-07-25', 'Joyce Tola', '631-631-6310', 'No Allergies', 'No Conditions', 'No Illnesses', '180/70', '70'),
(2, 4, NULL, 'Steven', 'Tola', 'Male', '2010-03-10', 'Joyce Tola', '631-631-6310', 'No Allergies', 'No Conditions', 'No Illnesses', '180/70', 'Normal'),
(3, NULL, NULL, 'Mark', 'White', 'Male', '2002-05-05', 'Ashley White', '631-344-6432', 'Pollen', 'Asthma', 'NONE', '121/80', 'Normal'),
(4, NULL, NULL, 'Leonard', 'Thompson', 'Male', '1981-04-21', 'John Thompson', '606-507-8418', 'Penicillin', 'Hypertension', 'Diabetes', '141/90', 'High'),
(5, NULL, NULL, 'Nora', 'Buckley', 'Female', '2000-04-29', 'Nicola Buckley', '434-876-1073', 'None', 'High Blood Pressure', 'Asthma', '140/90', 'High'),
(6, NULL, NULL, 'Sarah', 'Wilson', 'Female', '1980-03-10', 'David Wilson', '516-234-3123', 'Nuts', 'High Cholesterol', 'Arthritis', '130/85', 'High'),
(7, NULL, NULL, 'Emily', 'Brown', 'Female', '1995-07-25', 'Chris Brown', '516-009-9273', 'Eggs', 'Asthma', 'None', '125/78', 'Normal'),
(8, NULL, NULL, 'Daniel', 'Clark', 'Male', '1998-12-05', 'Maria Clark', '516-654-2002', 'Dust', 'Diabetes', 'Depression', '180/88', 'High'),
(9, NULL, NULL, 'Olivia', 'Anderson', 'Female', '1982-06-30', 'Michael Anderson', '516-022-1234', 'Peanuts', 'High Blood Pressure', 'None', '122/79', 'Normal'),
(10, NULL, NULL, 'William', 'Martinez', 'Male', '1993-04-12', 'Linda Martinez', '631-909-7621', 'Shellfish', 'Asthma', 'None', '130/83', 'Normal'),
(11, NULL, NULL, 'Sophia', 'Garcia', 'Female', '1997-10-18', 'Robert Garcia', '631-455-7821', 'Penicillin', 'High Cholesterol', 'Anxiety', '138/91', 'High'),
(12, NULL, NULL, 'James', 'Smith', 'Male', '1987-02-28', 'Jennifer Smith', '631-123-2345', 'Nuts', 'Hypertension', 'Depression', '132/86', 'High'),
(13, NULL, NULL, 'Ava', 'Lee', 'Female', '1991-11-14', 'Daniel Lee', '631-092-2348', 'Eggs', 'None', 'Migraine', '118/76', 'Normal'),
(14, NULL, NULL, 'Liam', 'Johnson', 'Male', '1989-08-07', 'Jessica Johnson', '718-672-1022', 'Pollen', 'Asthma', 'None', '126/82', 'Normal'),
(15, NULL, NULL, 'Mia', 'Gonzalez', 'Female', '1994-03-22', 'Anthony Gonzalez', '718-222-2222', 'Dust', 'High Cholesterol', 'Anxiety', '133/87', 'High'),
(16, NULL, NULL, 'Noah', 'Davis', 'Male', '1984-01-08', 'Lisa Davis', '718-333-3432', 'Shellfish', 'Hypertension', 'Depression', '129/84', 'High'),
(17, NULL, NULL, 'Isabella', 'Hernandez', 'Female', '1983-07-04', 'William Hernandez', '718-000-5555', 'Penicillin', 'None', 'None', '124/81', 'Normal'),
(18, NULL, NULL, 'Benjamin', 'Lopez', 'Male', '1996-12-30', 'Maria Lopez', '929-123-3455', 'Nuts', 'High Cholesterol', 'Migraine', '137/90', 'High'),
(19, NULL, NULL, 'Charlotte', 'Wilson', 'Female', '1981-09-11', 'John Wilson', '929-555-5571', 'Eggs', 'Asthma', 'Depression', '123/77', 'Normal'),
(20, NULL, NULL, 'Henry', 'Anderson', 'Male', '1990-05-03', 'Susan Anderson', '929-786-7381', 'Dust', 'Hypertension', 'None', '131/85', 'High'),
(21, NULL, NULL, 'Amelia', 'Thomas', 'Female', '1988-02-17', 'David Thomas', '929-390-0912', 'Pollen', 'None', 'Anxiety', '121/78', 'Normal'),
(22, NULL, NULL, 'Elijah', 'Hall', 'Male', '1999-08-25', 'Jennifer Hall', '929-505-1023', 'Shellfish', 'High Cholesterol', 'Migraine', '139/92', 'High'),
(23, NULL, NULL, 'Prince', 'Singh', 'Male', '1994-12-25', 'Snow Kaur', '516-234-5211', 'None', 'Asthma', 'None', '120/80', 'Normal'),
(24, NULL, NULL, 'Scarlet', 'Davis', 'Female', '1999-06-03', 'Cody Davis', '516-900-8715', 'Dog allergy', 'Depression', 'None', '120/80', 'Normal'),
(25, NULL, NULL, 'Lisa', 'Simpson', 'Female', '1975-11-13', 'Mateo Simpson', '631-2344-5142', 'None', 'None', 'None', '120/80', 'Normal');

-- --------------------------------------------------------

--
-- Table structure for table `prescription`
--

CREATE TABLE `prescription` (
  `PrescriptionID` int NOT NULL,
  `PatientID` int NOT NULL,
  `DoctorID` int NOT NULL,
  `Name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Reason` varchar(300) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Instructions` varchar(300) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `prescription`
--

INSERT INTO `prescription` (`PrescriptionID`, `PatientID`, `DoctorID`, `Name`, `Reason`, `Instructions`) VALUES
(2, 1, 1, 'Adderall', 'Issues with Focusing.', '1 Tablet (20mg) per day by mouth. Eat food beforehand.'),
(3, 8, 3, 'Loperamide', 'Bowel System not Working.', '2 capsules (4mg) twice a day.'),
(6, 13, 1, 'Loperamide', 'Bowel System not Working.', '2 capsules (4mg) twice a day.'),
(7, 12, 1, 'Dulaglutide', 'Diabetes.', '0.75mg/0.5mL shot once a week.');

-- --------------------------------------------------------

--
-- Table structure for table `secretary`
--

CREATE TABLE `secretary` (
  `SecretaryID` int NOT NULL,
  `UserID` int DEFAULT NULL,
  `FirstName` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `LastName` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `secretary`
--

INSERT INTO `secretary` (`SecretaryID`, `UserID`, `FirstName`, `LastName`) VALUES
(1, 5, 'Barry', 'Allen'),
(2, NULL, 'Diego', 'White'),
(3, NULL, 'Edward ', 'Collins'),
(4, NULL, 'Jacob', 'Black'),
(5, NULL, 'Nick', 'Joe');

-- --------------------------------------------------------

--
-- Table structure for table `userid`
--

CREATE TABLE `userid` (
  `UserID` int NOT NULL,
  `UserName` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Password` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Email` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `FirstName` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `LastName` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `userid`
--

INSERT INTO `userid` (`UserID`, `UserName`, `Password`, `Email`, `FirstName`, `LastName`) VALUES
(1, 'easonchang', '$2y$10$5R.enM1qO2JtOVao/m6G3uiQwacUIVfJZDPwGXPG1W0..gY3lhyqi', 'easonchang8866@gmail.com', 'Eason', 'Chang'),
(2, 'colemj', '$2y$10$omVmLNXJn8TS410.Yd78IewZuF2lFU9iVsU0UqQuSZXB79FVLe3qa', 'colemj1@farmingdale.edu', 'Michael', 'Colella'),
(3, 'atylerj', '$2y$10$ckCyrlQ8YGO7/qEzlbchPuIkoqyGUA6x1qDwU3hBQQW1c3/4Pzfne', 'atylerj07@gmail.com', 'Alyssa', 'Jimenez'),
(4, 'steventola', '$2y$10$HiIQZgEXISN2NiD89DMKIu6kNh2aOo1Rsays9.B4fSkQTBxb1pIIO', 'poop@gmail.com', 'Steven', 'Tola'),
(5, 'barryallen', '$2y$10$pzydhKeSfTb1aWwENEahCOCE9LFXSEOSEIUTuynsoqVZA4fPbMApy', 'ballen@gmail.com', 'Barry', 'Allen'),
(6, 'easonchang', '$2y$10$qAQJguuP6/L28kwrYjsiDuIlbvc7r4fIJS4GUFUPUoqWNVH7KlRa6', 'easonchang8866@gmail.com', 'Eason', 'Chang');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`AppointmentID`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`doctorid`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`PatientID`);

--
-- Indexes for table `prescription`
--
ALTER TABLE `prescription`
  ADD PRIMARY KEY (`PrescriptionID`);

--
-- Indexes for table `secretary`
--
ALTER TABLE `secretary`
  ADD PRIMARY KEY (`SecretaryID`);

--
-- Indexes for table `userid`
--
ALTER TABLE `userid`
  ADD PRIMARY KEY (`UserID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `AppointmentID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `doctorid` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `PatientID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `prescription`
--
ALTER TABLE `prescription`
  MODIFY `PrescriptionID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `secretary`
--
ALTER TABLE `secretary`
  MODIFY `SecretaryID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `userid`
--
ALTER TABLE `userid`
  MODIFY `UserID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
