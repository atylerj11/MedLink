<?php
    // Connection to database
        $server = 'localhost';
        $username = 'SeniorProjects';
        $password = 'Password';
        $db = 'MedLink';

        $conn = new mysqli($server, $username, $password, $db);

        if ($conn->connect_error) {
            die("Fatal Error: Database Connection");
        }

        if (isset($_POST['patient'])) {
            $patientID = $_POST['patient'];
        }

        if (isset($_POST['doctorid'])) {
            $doctorID = $_POST['doctorid'];
        }
    
        if (isset($_POST['prescription'])) {
            $prescription = $_POST['prescription'];
        }
    
        if (isset($_POST['reason'])) {
            $reason = $_POST['reason'];
        }
    
        if (isset($_POST['instructions'])) {
            $instructions = $_POST['instructions'];
        }

        // SQL query to insert the prescription into the "prescriptions" table
        $sql = "INSERT INTO prescription (PrescriptionID, PatientID, DoctorID, Name, Reason, Instructions) VALUES (NULL, ?, ?, ?, ?, ?)";

        // Prepare the SQL statement
        $stmt = $conn->prepare($sql);

        if ($stmt) {
            // Bind the parameters and execute the query
            $stmt->bind_param("sssss", $patientID, $doctorID, $prescription, $reason, $instructions);
            if ($stmt->execute()) {
                header("Location: success.php?success=2");
            } else {
                header("Location: error.php?error=6");
            }

            // Close the statement
            $stmt->close();
        } else {
            header("Location: error.php?error=6");
        }


    ?>