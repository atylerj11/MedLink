<?php

	//connection to database
    $server = 'localhost';
    $username = 'SeniorProjects';
    $password = 'Password';
    $db = 'MedLink';
    $conn = new mysqli($server, $username, $password, $db);
        
    if($conn->connect_error)
        die("Fatal Error: Database Connection");
        
    if(isset($_POST['username']))  //checking if posted
       $username = $_POST['username'];
       
    if(isset($_POST['email']))    
       $email = $_POST['email'];
   
   if(isset($_POST['FirstName']))    
       $firstname = $_POST['FirstName'];
   
   if(isset($_POST['LastName']))    
       $lastname = $_POST['LastName'];
   
    if(isset($_POST['password']))    
       $password = $_POST['password'];

    if(isset($_POST['confirmpassword']))    
       $confirm = $_POST['confirmpassword'];
    
    $hash     = password_hash($password, PASSWORD_DEFAULT);
       
       
    if($password != $confirm){
        echo "<p>Password Does Not Match, Please return to previous page.</p>";
    }else{
        
      
        $query = "INSERT INTO MedLink.UserID (UserID, Username, Password, Email, FirstName, LastName) VALUES (NULL, '$username', '$hash', '$email', '$firstname', '$lastname')";

        if (mysqli_query($conn, $query)) {
            echo "New user created successfully";
            echo "<p><a href='login_test.html'>Click here to Log In.</a></p>";
        } else {
            echo "Error: <br>" . mysqli_error($conn);
        }

        mysqli_close($conn);
            
    }
    
?>